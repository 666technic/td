import os
from weasyprint import HTML, CSS

# Define paths
html_path = '/home/ubuntu/trading_guide_project/pdf_compilation/index.html'
pdf_path = '/home/ubuntu/trading_guide_project/The_Definitive_SMC_ICT_XAUUSD_Trading_Guide.pdf'

# Create PDF from HTML
HTML(html_path).write_pdf(
    pdf_path,
    stylesheets=[
        # Add any additional CSS files if needed
    ]
)

print(f"PDF successfully created at: {pdf_path}")
