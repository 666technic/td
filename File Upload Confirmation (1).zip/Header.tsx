import React from 'react';
import Link from 'next/link';
import Image from 'next/image';

const Header = () => {
  return (
    <header className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="mr-4">
              <Image 
                src="/images/xauusd_ict_smc_vsa_comparison.png" 
                alt="XAUUSD Trading Guide Logo" 
                width={50} 
                height={50}
                className="rounded-full border-2 border-white"
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold">The Definitive SMC & ICT Guide</h1>
              <p className="text-sm">Mastering XAUUSD Scalping & Intraday Trading</p>
            </div>
          </div>
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link href="/" className="hover:text-yellow-200 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/terminology" className="hover:text-yellow-200 transition-colors">
                  Terminology
                </Link>
              </li>
              <li>
                <Link href="/scalping-strategies" className="hover:text-yellow-200 transition-colors">
                  Strategies
                </Link>
              </li>
              <li>
                <Link href="/risk-management" className="hover:text-yellow-200 transition-colors">
                  Risk Management
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
