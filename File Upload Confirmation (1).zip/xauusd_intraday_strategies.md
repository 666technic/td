# Top 10 XAUUSD Intraday Strategies Using SMC & ICT Principles

This section presents ten high-probability intraday strategies for XAUUSD based on Smart Money Concepts (SMC) and Inner Circle Trader (ICT) principles. These strategies are designed for trading within a single day, typically using 15-minute to 4-hour timeframes for analysis and 5-minute to 15-minute timeframes for execution.

## Strategy 1: The HTF Order Block Entry

This strategy focuses on entering trades at significant Order Blocks identified on higher timeframes (4-hour or Daily) for intraday positions.

### Market Context
- Works in both trending and ranging markets
- Most effective when aligned with the dominant HTF trend
- Particularly powerful at key support/resistance levels
- Higher probability when Order Block is fresh (not yet mitigated)

### Core SMC/ICT Logic
Significant Order Blocks on higher timeframes represent areas where institutions have placed large orders. When price returns to these zones, the unfilled orders often create strong reactions that can initiate substantial intraday moves. XAUUSD tends to respect HTF Order Blocks clearly, providing reliable entry opportunities.

### Timeframe Structure
- **HTF (4-hour/Daily)**: Identify significant Order Blocks and overall bias
- **MTF (1-hour)**: Confirm Order Block validity and monitor approach
- **LTF (15-minute)**: Identify entry triggers and refine stop placement
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Valid HTF Order Block with clear boundaries
2. Price returning to the Order Block with decreasing momentum
3. Rejection candle pattern forming on the 15-minute chart
4. RSI or MACD divergence on the 1-hour chart (optional but adds confluence)

### Step-by-Step Execution
1. Identify a significant Order Block on the 4-hour or Daily chart
2. Wait for price to return to the Order Block
3. Switch to 1-hour and 15-minute charts to monitor price reaction
4. Enter when a strong rejection candle forms on the 15-minute chart
5. Place stop loss beyond the HTF Order Block (typically 20-30 pips in XAUUSD)
6. Target the next significant HTF structure or a minimum 1:3 risk-reward
7. Consider partial profit at 1:2 and move stop to breakeven

### Risk Management
- Maximum risk per trade: 1-1.5% of account
- Wider stops required due to HTF analysis
- Avoid trading against strong HTF momentum without clear reversal signals
- Consider time-based exits if trade doesn't develop within the session

## Strategy 2: The Intraday FVG Reversal

This strategy exploits the tendency of XAUUSD to reverse after filling significant Fair Value Gaps (FVGs) identified on intraday timeframes.

### Market Context
- Works best in trending or moderate ranging conditions
- Most effective during London and NY sessions
- Higher probability when FVG aligns with other SMC/ICT concepts
- Particularly powerful after strong directional moves

### Core SMC/ICT Logic
Fair Value Gaps represent imbalances that often act as magnets for price. Once an FVG is filled, the imbalance is resolved, and price frequently reverses or continues its original direction. This strategy focuses on the reversal potential after an FVG fill. XAUUSD creates clear FVGs, making this strategy effective.

### Timeframe Structure
- **HTF (1-hour)**: Identify significant FVGs and overall bias
- **MTF (15-minute)**: Confirm FVG validity and monitor fill
- **LTF (5-minute)**: Identify reversal pattern after FVG fill
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Clear FVG on the 1-hour chart being filled
2. Price showing rejection after filling the FVG
3. Reversal candle pattern forming on the 5-minute chart
4. Momentum indicator shift confirming the reversal

### Step-by-Step Execution
1. Identify a significant FVG on the 1-hour chart
2. Wait for price to completely fill the FVG
3. Look for signs of rejection and reversal on the 5-minute chart
4. Enter when a strong reversal candle forms after the FVG fill
5. Place stop loss beyond the FVG extreme (typically 15-20 pips in XAUUSD)
6. Target the origin of the move that created the FVG or the next significant structure
7. Trail stops once price moves 1:1.5 risk-reward in your favor

### Risk Management
- Maximum risk per trade: 1% of account
- Ensure FVG fill is complete before looking for reversal
- Avoid trading against strong HTF momentum without clear confirmation
- Consider reducing position size if FVG is very large

## Strategy 3: The Session Liquidity Grab

This strategy capitalizes on institutional manipulation of session highs/lows, entering after a liquidity sweep and reversal during intraday trading.

### Market Context
- Works in both trending and ranging markets
- Most effective at London and NY session transitions
- Higher probability at significant daily or weekly levels
- Particularly powerful when sweep aligns with HTF bias

### Core SMC/ICT Logic
Institutions often target liquidity resting above previous session highs or below previous session lows. After sweeping this liquidity, they reverse price in their intended direction. This strategy aims to enter after the sweep and capture the subsequent reversal move. XAUUSD exhibits clear session liquidity grabs.

### Timeframe Structure
- **HTF (4-hour)**: Identify overall bias and key daily/weekly levels
- **MTF (1-hour)**: Mark previous session high/low
- **LTF (15-minute)**: Confirm sweep and reversal pattern
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Price sweeping beyond previous session high/low
2. Immediate rejection with strong reversal candle on 15-minute chart
3. BOS (Break of Structure) on the 5-minute chart confirming reversal
4. Volume increase (if available) during reversal

### Step-by-Step Execution
1. Identify previous session high and low on the 1-hour chart
2. Wait for price to sweep beyond one of these levels
3. Look for immediate rejection with a strong reversal candle on the 15-minute chart
4. Confirm reversal with a BOS on the 5-minute chart
5. Enter on a pullback to the BOS level or nearby Order Block
6. Place stop loss beyond the sweep extreme (typically 15-25 pips in XAUUSD)
7. Target the opposite session extreme or the next significant HTF level

### Risk Management
- Maximum risk per trade: 1% of account
- Wider stops may be needed during volatile sweeps
- Avoid chasing sweeps that don't show immediate reversal
- Be cautious of multiple sweeps in choppy conditions

## Strategy 4: The Intraday BOS Continuation

This strategy focuses on entering during pullbacks after a confirmed Break of Structure (BOS) on intraday timeframes, aiming to capture the trend continuation.

### Market Context
- Works best in established trending conditions
- Most effective during London and NY sessions
- Higher probability when aligned with HTF trend
- Particularly powerful after breaking significant intraday structure

### Core SMC/ICT Logic
A confirmed BOS on intraday charts signals likely trend continuation. Price often pulls back to the broken structure or a nearby Order Block/FVG before resuming the trend. This pullback provides a low-risk entry opportunity. XAUUSD trends often exhibit clear BOS patterns.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall trend and significant structure
- **MTF (15-minute)**: Confirm BOS and monitor pullback
- **LTF (5-minute)**: Identify entry zone (Order Block, FVG) during pullback
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Clear BOS on the 15-minute chart
2. Pullback to a valid Order Block or FVG created during the BOS move
3. Rejection candle pattern forming at the entry zone
4. Momentum indicator alignment with the trend direction

### Step-by-Step Execution
1. Identify a clear BOS on the 15-minute chart
2. Wait for a pullback to a valid Order Block or FVG within the BOS range
3. Look for rejection at this level with a strong candle on the 5-minute chart
4. Enter on the close of the rejection candle
5. Place stop loss beyond the entry zone structure (typically 12-18 pips in XAUUSD)
6. Target the next significant structure or a minimum 1:2 risk-reward
7. Trail stops aggressively once price moves significantly in your favor

### Risk Management
- Maximum risk per trade: 1% of account
- Ensure BOS is clear and decisive
- Avoid trading BOS against major HTF structure
- Consider reducing position size if pullback is very deep

## Strategy 5: The Killzone Reversal

This strategy targets potential reversals occurring during specific ICT Killzones (Asian, London, NY), often coinciding with institutional manipulation.

### Market Context
- Specifically designed for ICT Killzone periods
- Most effective during London and NY Killzones
- Higher probability when reversal aligns with HTF bias
- Particularly powerful after strong moves in the previous session

### Core SMC/ICT Logic
ICT Killzones represent periods of heightened institutional activity. During these times, institutions often manipulate price to create liquidity before initiating their intended move, frequently leading to reversals of the previous trend or session direction. XAUUSD shows distinct behavior during different Killzones.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall bias and key levels
- **MTF (15-minute)**: Monitor price action during the Killzone
- **LTF (5-minute)**: Identify potential reversal pattern (sweep, BOS, CHoCH)
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Price action occurring within a defined Killzone
2. Liquidity sweep of previous session/range high/low
3. Strong reversal pattern (engulfing, pin bar) on 15-minute chart
4. BOS or CHoCH on the 5-minute chart confirming reversal

### Step-by-Step Execution
1. Identify the current ICT Killzone (Asian, London, NY)
2. Monitor price action for potential manipulation patterns (sweeps, false breaks)
3. Look for a strong reversal pattern forming during the Killzone
4. Confirm reversal with BOS or CHoCH on the 5-minute chart
5. Enter on a pullback after the confirmation
6. Place stop loss beyond the reversal extreme (typically 15-20 pips in XAUUSD)
7. Target the next significant structure or the opposite end of the Killzone range

### Risk Management
- Maximum risk per trade: 1% of account
- Be aware of increased volatility during Killzones
- Avoid forcing trades if no clear pattern emerges
- Consider time-based exits if trade doesn't develop within the Killzone

## Strategy 6: The Intraday Breaker Block Entry

This strategy focuses on entering trades at retests of significant Breaker Blocks identified on intraday timeframes.

### Market Context
- Works best in established trending conditions
- Most effective during London and NY sessions
- Higher probability when aligned with HTF trend
- Particularly powerful after breaking significant intraday Order Blocks

### Core SMC/ICT Logic
When a significant intraday Order Block is broken, it transforms into a Breaker Block, acting as strong support/resistance upon retest. These retests offer high-probability continuation entries in the direction of the break. XAUUSD tends to respect intraday Breaker Blocks clearly.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall trend and significant structure
- **MTF (15-minute)**: Identify significant Breaker Blocks
- **LTF (5-minute)**: Confirm Breaker Block validity and monitor retest
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Clear Breaker Block formation on the 15-minute chart
2. Price returning to test the Breaker Block from the opposite side
3. Rejection candle pattern forming at the Breaker Block on 5-minute chart
4. Momentum indicator alignment with the overall trend

### Step-by-Step Execution
1. Identify a significant Breaker Block on the 15-minute chart
2. Wait for price to return to test this Breaker Block
3. Look for rejection at the Breaker Block level with a strong candle on the 5-minute chart
4. Enter on the close of the rejection candle
5. Place stop loss beyond the Breaker Block (typically 12-18 pips in XAUUSD)
6. Target the next significant structure in the trend direction
7. Trail stops once price moves 1:1.5 risk-reward in your favor

### Risk Management
- Maximum risk per trade: 1% of account
- Ensure the original Order Block was significant
- Avoid trading Breaker Blocks that have been tested multiple times
- Consider reducing position size if Breaker Block is against HTF bias

## Strategy 7: The AMD Cycle Trade

This strategy aims to identify and trade the Distribution phase of the Accumulation, Manipulation, Distribution (AMD) cycle, common in XAUUSD.

### Market Context
- Works in both trending and ranging markets (identifies transitions)
- Most effective during session transitions (Asian to London, London to NY)
- Higher probability when manipulation phase sweeps significant liquidity
- Particularly powerful for identifying intraday trend initiation

### Core SMC/ICT Logic
The AMD cycle describes institutional behavior: Accumulation (building positions), Manipulation (sweeping liquidity), and Distribution (directional move). This strategy focuses on entering during the early stages of the Distribution phase after confirming the Manipulation phase. XAUUSD often exhibits clear AMD cycles.

### Timeframe Structure
- **HTF (1-hour)**: Identify potential Accumulation ranges
- **MTF (15-minute)**: Monitor for Manipulation (sweep) phase
- **LTF (5-minute)**: Confirm reversal after Manipulation and entry for Distribution
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Clear Accumulation range identified on 1-hour chart
2. Manipulation phase sweeping liquidity above/below the range
3. Strong reversal after the sweep, often creating an FVG
4. BOS on the 5-minute chart confirming start of Distribution phase

### Step-by-Step Execution
1. Identify a period of Accumulation (consolidation) on the 1-hour chart
2. Wait for the Manipulation phase (liquidity sweep beyond the range)
3. Look for a strong reversal after the sweep
4. Confirm the start of the Distribution phase with a BOS on the 5-minute chart
5. Enter on a pullback to the BOS level or nearby Order Block/FVG
6. Place stop loss beyond the Manipulation extreme (typically 20-30 pips in XAUUSD)
7. Target significant structure or a measured move based on the Accumulation range

### Risk Management
- Maximum risk per trade: 1-1.5% of account
- Wider stops often required due to Manipulation phase volatility
- Ensure clear distinction between the three phases
- Avoid entering too early before Distribution is confirmed

## Strategy 8: The Optimal Trade Entry (OTE) Pullback

This strategy utilizes the ICT Optimal Trade Entry (OTE) concept, entering during pullbacks to specific Fibonacci levels within a significant price swing in XAUUSD.

### Market Context
- Works best in established trending conditions
- Most effective during London and NY sessions
- Higher probability when OTE levels align with other SMC/ICT concepts
- Particularly powerful after strong impulse moves

### Core SMC/ICT Logic
Optimal Trade Entry (OTE) refers to the Fibonacci retracement zone between 61.8% and 79% of a significant price swing. This zone is considered optimal for entering trades in the direction of the original swing. XAUUSD often respects these OTE levels precisely.

### Timeframe Structure
- **HTF (1-hour)**: Identify significant price swings and overall trend
- **MTF (15-minute)**: Draw Fibonacci retracement and monitor OTE zone
- **LTF (5-minute)**: Identify entry trigger within the OTE zone
- **ETF (5-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Clear impulse swing aligned with HTF trend
2. Price pulling back into the OTE zone (61.8%-79% Fib levels)
3. OTE zone aligning with an Order Block or FVG
4. Reversal candle pattern forming within the OTE zone on 5-minute chart

### Step-by-Step Ex
(Content truncated due to size limit. Use line ranges to read in chunks)