# Strategy Templates with Visual Examples

This section provides ready-to-use strategy templates with detailed visual examples for implementing the XAUUSD scalping and intraday strategies covered in previous sections. These templates offer a structured framework for trade identification, execution, and management.

## Strategy Template Structure

Each template follows a consistent format to ensure comprehensive trade planning and execution:

### 1. Setup Identification Template

```
STRATEGY NAME: [e.g., Order Block Reversal Scalp]
DATE/TIME: [Current date and time]
TIMEFRAME: [Analysis timeframe]
MARKET CONDITION: [Trending/Ranging/Transitioning]
HIGHER TIMEFRAME BIAS: [Bullish/Bearish/Neutral]

SETUP CRITERIA:
□ Criterion 1: [e.g., Valid Order Block identified]
□ Criterion 2: [e.g., Price returning to Order Block]
□ Criterion 3: [e.g., Rejection candle forming]
□ Criterion 4: [e.g., RSI showing momentum shift]

CONFLUENCE FACTORS:
□ Factor 1: [e.g., Order Block aligns with round number]
□ Factor 2: [e.g., Previous reaction at this level]
□ Factor 3: [e.g., Indicator confirmation]

INVALIDATION CRITERIA:
□ Criterion 1: [e.g., Price closes beyond Order Block]
□ Criterion 2: [e.g., No rejection within X candles]
□ Criterion 3: [e.g., HTF bias changes]
```

### 2. Trade Execution Template

```
ENTRY PARAMETERS:
Entry Price: [Specific price level]
Entry Trigger: [e.g., Close of rejection candle]
Entry Timeframe: [Execution timeframe]

RISK MANAGEMENT:
Stop Loss: [Specific price level]
Stop Loss Distance: [X pips]
Position Size: [X% of account]
Risk Amount: [$X]

TARGET PARAMETERS:
Target 1 (XX%): [Specific price level - X pips]
Target 2 (XX%): [Specific price level - X pips]
Target 3 (XX%): [Specific price level - X pips]
Risk:Reward Ratio: [e.g., 1:3]

TRADE MANAGEMENT RULES:
□ Rule 1: [e.g., Move stop to breakeven after Target 1]
□ Rule 2: [e.g., Trail stop using X indicator]
□ Rule 3: [e.g., Close position if X occurs]
```

### 3. Post-Trade Analysis Template

```
TRADE OUTCOME:
Entry Executed: [Yes/No]
Entry Price Achieved: [Actual entry price]
Maximum Favorable Excursion: [X pips]
Maximum Adverse Excursion: [X pips]
Exit Price: [Actual exit price]
Profit/Loss: [X pips / $X / X%]

ANALYSIS:
What Worked: [Analysis of successful elements]
What Could Be Improved: [Analysis of challenges]
Lessons Learned: [Key takeaways]
Adjustments for Next Trade: [Specific improvements]
```

## Visual Example 1: Order Block Reversal Scalp

### Setup Identification

![Order Block Identification Chart]

**Key Elements in Visual:**
- Higher timeframe (1-hour) chart showing overall context
- Clearly marked Order Block with labeled mitigation zone
- Previous price reactions at the Order Block
- Current price approaching the Order Block
- RSI indicator showing potential divergence

### Trade Execution

![Order Block Entry Chart]

**Key Elements in Visual:**
- Lower timeframe (5-minute) chart showing entry precision
- Rejection candle marked at Order Block
- Entry point clearly indicated
- Stop loss placement beyond Order Block
- Target levels based on structure
- RSI showing momentum shift at entry

### Trade Management

![Order Block Management Chart]

**Key Elements in Visual:**
- Trade progression after entry
- Stop loss adjustment points
- Partial profit taking levels
- Final exit point
- Price path relative to targets

## Visual Example 2: Intraday HTF Order Block Entry

### Setup Identification

![HTF Order Block Identification Chart]

**Key Elements in Visual:**
- Higher timeframe (4-hour) chart showing overall context
- Clearly marked HTF Order Block with labeled mitigation zone
- Previous price reactions at the Order Block
- Current price approaching the Order Block
- Volume profile showing significance of the zone

### Trade Execution

![HTF Order Block Entry Chart]

**Key Elements in Visual:**
- Lower timeframe (15-minute) chart showing entry precision
- Rejection candle marked at Order Block
- Entry point clearly indicated
- Stop loss placement beyond Order Block
- Target levels based on HTF structure
- MACD showing momentum shift at entry

### Trade Management

![HTF Order Block Management Chart]

**Key Elements in Visual:**
- Trade progression after entry
- Stop loss adjustment points
- Partial profit taking levels
- Final exit point
- Price path relative to targets

## Visual Example 3: Fair Value Gap Fill Scalp

### Setup Identification

![FVG Identification Chart]

**Key Elements in Visual:**
- Higher timeframe (15-minute) chart showing overall context
- Clearly marked Fair Value Gap with labeled boundaries
- Previous price reactions at similar FVGs
- Current price approaching the FVG
- Bollinger Bands showing volatility contraction

### Trade Execution

![FVG Entry Chart]

**Key Elements in Visual:**
- Lower timeframe (1-minute) chart showing entry precision
- Entry candle marked as price enters FVG
- Entry point clearly indicated
- Stop loss placement beyond recent structure
- Target at complete FVG fill
- Stochastic showing momentum in entry direction

### Trade Management

![FVG Management Chart]

**Key Elements in Visual:**
- Trade progression after entry
- Stop loss adjustment points
- Partial profit taking levels
- Final exit point
- Price path relative to FVG fill

## Visual Example 4: Liquidity Sweep Reversal

### Setup Identification

![Liquidity Sweep Identification Chart]

**Key Elements in Visual:**
- Higher timeframe (1-hour) chart showing overall context
- Clearly marked liquidity level (previous session high/low)
- Equal highs/lows indicating potential liquidity
- Current price approaching the liquidity level
- RSI showing potential divergence setup

### Trade Execution

![Liquidity Sweep Entry Chart]

**Key Elements in Visual:**
- Lower timeframe (5-minute) chart showing entry precision
- Sweep beyond liquidity level clearly marked
- Reversal candle identified
- Entry point on confirmation
- Stop loss placement beyond sweep extreme
- Targets based on origin of sweep move
- RSI showing divergence at sweep point

### Trade Management

![Liquidity Sweep Management Chart]

**Key Elements in Visual:**
- Trade progression after entry
- Stop loss adjustment points
- Partial profit taking levels
- Final exit point
- Price path relative to targets

## Visual Example 5: BOS Confirmation Scalp

### Setup Identification

![BOS Identification Chart]

**Key Elements in Visual:**
- Higher timeframe (15-minute) chart showing overall context
- Clearly marked Break of Structure (BOS)
- Previous market structure highlighted
- Current price pulling back after BOS
- Fibonacci retracement levels drawn on BOS move

### Trade Execution

![BOS Entry Chart]

**Key Elements in Visual:**
- Lower timeframe (5-minute) chart showing entry precision
- Pullback to 50-61.8% Fibonacci level
- Reversal candle at pullback level
- Entry point clearly indicated
- Stop loss placement beyond pullback swing
- Targets based on projection of BOS move
- MACD showing momentum resumption at entry

### Trade Management

![BOS Management Chart]

**Key Elements in Visual:**
- Trade progression after entry
- Stop loss adjustment points
- Partial profit taking levels
- Final exit point
- Price path relative to targets

## Implementation Guidelines

To effectively use these templates and visual examples:

### 1. Pre-Trade Preparation

- Print or create digital copies of the templates for each trading session
- Review the visual examples to internalize the patterns
- Prepare your charts with the necessary indicators and drawing tools
- Set up multiple timeframe analysis as shown in the examples

### 2. During Trading Session

- Scan for setups that match the template criteria
- Complete the Setup Identification template when a potential trade is found
- Verify all criteria and confluence factors are present
- Complete the Trade Execution template before placing any orders
- Follow the trade management rules precisely

### 3. Post-Trade Review

- Complete the Post-Trade Analysis template after each trade
- Compare your trade to the visual examples
- Identify similarities and differences
- Make specific adjustments for future trades

### 4. Continuous Improvement

- Maintain a library of your completed templates
- Review periodically to identify patterns in successful and unsuccessful trades
- Refine your criteria based on results
- Develop your own visual examples from successful trades

By consistently using these templates and studying the visual examples, you'll develop a structured approach to XAUUSD trading using SMC and ICT principles. This systematic process helps eliminate emotional decision-making and builds consistent trading habits.

[Note: In the final PDF, this section will include actual annotated chart images for each visual example described above, showing real XAUUSD price action with all the key elements clearly marked.]
