# Advanced ICT Concepts for XAUUSD Trading

This section explores advanced Inner Circle Trader (ICT) concepts specifically applied to XAUUSD trading. These sophisticated techniques build upon the foundational SMC principles covered earlier and provide deeper insights into institutional trading practices in gold markets.

## Premium/Discount (PD) Array

The Premium/Discount Array represents a range between a premium price (high) and discount price (low) where smart money accumulates positions. Understanding this concept helps identify optimal entry zones.

### Definition and Identification

**Core Concept:**
- PD Array is the range between a significant high (premium) and low (discount)
- Represents the zone where institutions build positions
- Typically forms after a strong directional move
- In XAUUSD, often more pronounced due to gold's volatility
- Creates a framework for identifying optimal entries

**Identification Process:**
1. Identify a significant directional move (impulse wave)
2. Mark the origin (start) and extreme (end) of the move
3. The range between these points forms the PD Array
4. Apply Fibonacci retracement to this range
5. Key levels within the array (50%, 61.8%, 70.5%, 79%) become potential entry points
6. In XAUUSD, the 61.8% and 70.5% levels are particularly significant

### XAUUSD-Specific Applications

Gold markets exhibit unique characteristics that affect PD Array trading:

**Volatility Considerations:**
- XAUUSD's higher volatility creates wider PD Arrays
- Requires slightly wider stop placement than forex pairs
- Often leads to more dramatic reactions at key Fibonacci levels
- Creates clearer entry opportunities with better risk-reward

**Session Influence:**
- PD Arrays formed during NY session tend to be more significant
- Arrays that span multiple sessions often provide the most reliable entries
- Asian session often tests key levels within arrays formed during London/NY
- Creates session-specific trading opportunities

**Economic Catalyst Impact:**
- PD Arrays formed after major gold-impacting news tend to be more reliable
- Post-FOMC, NFP, or inflation data arrays are particularly significant
- The reaction speed at key levels indicates institutional interest
- Creates opportunities for anticipating future price direction

## Optimal Trade Entry (OTE)

Optimal Trade Entry represents specific levels within a PD Array that offer the best risk-reward for entries. This concept is central to precision entry in ICT methodology.

### The 61.8%, 70.5%, and 79% Sweet Spots

**Key OTE Levels:**
- 61.8%: The primary OTE level, represents the "golden pocket"
- 70.5%: Secondary OTE level, often used when 61.8% is broken
- 79%: Tertiary OTE level, the final defense before trend change
- In XAUUSD, these levels often align with round numbers, creating enhanced significance
- The precision of reactions at these levels is typically higher in gold than many forex pairs

**Selection Criteria:**
- Trend strength determines which level to target
- Strong trends: 61.8% often holds
- Moderate trends: 70.5% may be required
- Weak trends: 79% becomes the final opportunity
- In XAUUSD, volatility may cause brief spikes beyond these levels before reversal

### Combining OTE with Order Blocks and FVGs

The power of OTE increases dramatically when combined with other SMC/ICT concepts:

**OTE + Order Block:**
- When an OTE level aligns with a significant Order Block
- Creates a high-probability reversal zone
- Particularly effective in XAUUSD during trend continuations
- Often forms after news-induced volatility in gold markets

**OTE + Fair Value Gap:**
- When an OTE level aligns with an unfilled Fair Value Gap
- Creates a "magnetic" effect on price
- Common during strong trend days in XAUUSD
- Provides precise entry levels with clear stop placement

**OTE + Liquidity Level:**
- When an OTE level aligns with a significant liquidity level
- Often creates stop hunts before reversals
- Particularly common at session transitions in gold markets
- Requires patience and precise entry timing

### XAUUSD Chart Examples

[Note: This section will include annotated XAUUSD chart examples showing OTE concepts in action]

## Killzones: Optimal Trading Windows for XAUUSD

Killzones represent specific time windows during trading sessions when institutional activity increases, creating high-probability trading opportunities. Understanding these windows is particularly important for XAUUSD trading.

### Asian, London, and New York Killzones

**Asian Killzone (00:00-04:00 GMT):**
- Typically lower volatility in XAUUSD
- Often establishes the range for London session
- Key characteristics:
  - Consolidation patterns
  - Tight ranges
  - Limited directional movement
  - Accumulation before London open
- Trading opportunities:
  - Range-bound strategies
  - Preparing for London breakouts
  - Identifying potential liquidity levels for London session

**London Killzone (08:00-10:00 GMT):**
- Significant increase in XAUUSD volatility
- Often breaks Asian session ranges
- Key characteristics:
  - Directional moves
  - Liquidity sweeps of Asian highs/lows
  - Establishment of intraday trend
  - Creation of significant Order Blocks
- Trading opportunities:
  - Asian range breakouts
  - Fading false breakouts
  - Early trend identification
  - Order Block formation for later retests

**New York Killzone (13:30-16:30 GMT):**
- Highest liquidity and volatility in XAUUSD
- Often confirms or reverses London session direction
- Key characteristics:
  - Strong directional moves
  - Liquidity sweeps of London highs/lows
  - Reaction to US economic data
  - Significant price discovery
- Trading opportunities:
  - London trend continuation or reversal
  - News-based momentum trades
  - End-of-day positioning
  - Formation of significant daily Order Blocks

### XAUUSD-Specific Killzone Characteristics

Gold exhibits unique behavior during different killzones:

**Asian Session Specifics:**
- XAUUSD often respects technical levels more precisely during Asian hours
- Lower volatility creates cleaner support/resistance levels
- Often establishes key levels that become liquidity targets during London
- Particularly influenced by Chinese market activity

**London Session Specifics:**
- Gold frequently shows strong directional bias during early London hours
- Often creates significant Order Blocks that become valid for days
- European economic data can trigger substantial moves
- Physical gold demand from European markets influences price action

**New York Session Specifics:**
- Highest correlation between XAUUSD and US dollar movements
- US economic data creates the largest volatility events
- FOMC announcements produce the most significant trend changes
- Often establishes the daily high or low during this session

### Optimal Setups for Each Killzone

Different killzones favor different trading approaches in XAUUSD:

**Asian Killzone Setups:**
- Range identification and boundaries
- Accumulation patterns
- Preparation for London breakouts
- Identifying potential liquidity levels

**London Killzone Setups:**
- Asian range breakouts
- Early trend identification
- Order Block formation
- Liquidity sweeps of Asian session highs/lows

**New York Killzone Setups:**
- London trend continuation or reversal
- News-based momentum trades
- Daily high/low formations
- End-of-day positioning

## Power of 3 (PO3) / Accumulation, Manipulation, Distribution (AMD)

The Power of 3 (PO3) or Accumulation, Manipulation, Distribution (AMD) concept represents the three phases of institutional trading. Understanding this cycle helps anticipate market movements.

### The Three Phases Explained

**Phase 1: Accumulation**
- Institutions build positions at favorable prices
- Characterized by:
  - Sideways or slightly contrary movement
  - Reduced volatility
  - False breakouts to discourage retail traders
  - Creation of significant Order Blocks
- In XAUUSD, often occurs during Asian session or pre-news consolidation
- Creates the foundation for subsequent directional moves

**Phase 2: Manipulation**
- Institutions trigger retail stops to generate liquidity
- Characterized by:
  - Sharp, often counter-intuitive moves
  - Liquidity sweeps of obvious levels
  - Violation of technical patterns to trigger stops
  - Creation of Fair Value Gaps
- In gold markets, particularly dramatic due to higher volatility
- Often coincides with news events or session transitions

**Phase 3: Distribution**
- Institutions offload positions to retail traders at favorable prices
- Characterized by:
  - Strong directional movement
  - Increased volatility
  - FOMO-inducing price action
  - Exhaustion signals near the end
- In XAUUSD, often occurs during NY session
- Creates the conditions for the next accumulation phase

### Identifying Current Phase in XAUUSD

Recognizing which phase the market is currently in helps anticipate future movements:

**Accumulation Indicators:**
- Reduced volatility
- Tight ranges
- Multiple tests of support/resistance without breaking
- Failed breakouts returning to range
- Common during Asian session in XAUUSD
- Often precedes major economic announcements

**Manipulation Indicators:**
- Sudden increases in volatility
- Sweeps of obvious support/resistance levels
- Violation of technical patterns
- Quick reversals after liquidity sweeps
- Often occurs at session transitions in gold markets
- Frequently coincides with minor economic releases

**Distribution Indicators:**
- Strong, sustained directional movement
- Increased volume (when visible)
- Minimal pullbacks
- Retail FOMO evident in social media
- Often occurs during major trend days in XAUUSD
- Frequently follows significant economic catalysts

### Trading Each Phase in Gold Markets

Different phases require different trading approaches:

**Accumulation Phase Strategies:**
- Avoid over-trading
- Prepare for breakout opportunities
- Identify potential Order Blocks forming
- Consider reduced position sizing
- In XAUUSD, particularly important during pre-FOMC consolidation

**Manipulation Phase Strategies:**
- Look for liquidity sweeps to fade
- Identify stop hunts at obvious levels
- Prepare for reversal opportunities
- Use limit orders at key levels
- In gold markets, requires quick decision-making due to volatility

**Distribution Phase Strategies:**
- Trade with the trend
- Look for pullbacks to key levels
- Be alert for exhaustion signals
- Prepare for eventual reversal
- In XAUUSD, can provide the largest profit opportunities

## Displacement

Displacement represents powerful, momentum-based moves in price that create significant imbalances and often indicate institutional participation. Gold is known for strong displacement moves, especially during major economic announcements.

### Definition and Significance

**Core Concept:**
- Displacement is a strong directional move that creates separation from previous price structure
- Represents institutional commitment to direction
- Creates significant imbalances and Fair Value Gaps
- In XAUUSD, typically more dramatic than in forex pairs
- Often occurs after consolidation periods

**Significance Factors:**
- Magnitude of the move
- Volume during displacement (when visible)
- Context within larger market structure
- Timeframe on which it occurs
- In gold markets, particularly significant when aligned with fundamental catalysts

### Types of Displacement in XAUUSD

Gold markets exhibit several distinct types of displacement:

**News-Driven Displacement:**
- Occurs after major economic releases
- Characterized by:
  - Extremely rapid price movement
  - Large candles with minimal wicks
  - Creation of significant Fair Value Gaps
  - Limited pullbacks during the move
- Most common after FOMC, NFP, CPI, or geopolitical events
- Creates some of the most reliable subsequent trading opportunities

**Technical Displacement:**
- Occurs after breakouts from significant technical levels
- Characterized by:
  - Strong momentum after breaking key levels
  - Increasing participation as the move progresses
  - Often follows period of consolidation
  - Creates significant Order Blocks for future reference
- Common after breaking major support/resistance or round numbers in XAUUSD
- Often leads to multi-day trends

**Session Transition Displacement:**
- Occurs during transitions between major trading sessions
- Characterized by:
  - Breakouts from previous session ranges
  - Liquidity sweeps followed by strong directional movement
  - Often begins during early London or early NY hours
  - Creates intraday trend direction
- Particularly common at London open in gold markets
- Creates opportunities for session-based trading strategies

### Trading Displacement in Gold Markets

Displacement creates specific trading opportunities in XAUUSD:

**During Displacement:**
- Momentum entries in direction of displacement
- Adding to positions on micro-pullbacks
- Trailing stops to capture maximum movement
- Requires quick decision-making due to speed of movement

**After Displacement:**
- Identifying the Order Block that initiated the displacement
- Trading pullbacks to key levels within the displacement
- Monitoring unfilled Fair Value Gaps created during the move
- In XAUUSD, these opportunities often provide better risk-reward than entries during the displacement itself

**Counter-Displacement Opportunities:**
- Identifying exhaustion signals at the end of displacement
- Trading reversals after over-extended moves
- Using Fibonacci extensions to project potential reversal zones
- Particularly effective after news-driven displacements in gold markets

## Institutional Order Flow Patterns

Understanding how institutional orders flow through the market helps anticipate price movements and identify optimal entry points.

### Absorption vs. Distribution Footprints

**Absorption Footprint:**
- Institutions absorbing retail selling or buying
- Characterized by:
  - Limited price movement despite significant volume
  - Rejection of extreme prices
  - Creation of significant Order Blocks
  - Often occurs at key support/resistance levels
- In XAUUSD, common at major round numbers
- Creates high-probability reversal opportunities

**Distribution Footprint:**
- Institutions distributing positions to retail traders
- Characterized by:
  - Strong directional movement
  - Increasing momentum
  - Limited pullbacks
  - Often occurs after extended trends
- In gold markets, frequently seen during major trend days
- Creates opportunities for trend continuation and eventual reversal

### Identifying Smart Money Footprints in XAUUSD

Specific patterns indicate institutional activity in gold markets:

**Smart Money Entry Patterns:**
- Multiple tests of a level without breaking
- Decreasing volatility before directional move
- Creation of stop liquidity before reversal
- Quick rejection of extreme prices
- Particularly visible at key psychological levels in XAUUSD

**Smart Money Exit Patterns:**
- Increasing volatility after extended move
- Creation of liquidity to facilitate position exit
- Multiple rejections of further extension
- Failure to make progress despite momentum
- Often coincides with divergence on momentum indicators

### XAUUSD-Specific Order Flow Considerations

Gold markets have unique order flow characteristics:

**Physical Market Influence:**
- Unlike pure forex, physical gold demand affects price
- Central bank buying/selling creates significant footprints
- Seasonal patterns in jewelry demand (especially from India/China)
- Creates longer-term trends that affect short-term order flow

**Safe Haven Dynamics:**
- Gold's role as a safe haven affects institutional positioning
- Risk-off environments create distinctive order flow patterns
- Correlation with equity markets often inverts during crises
- Creates opportunities during periods of market stress

**USD Correlation:**
- Strong inverse correlation with USD
- USD order flow often provides leading indications for gold
- Mul
(Content truncated due to size limit. Use line ranges to read in chunks)