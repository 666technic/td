# Strategy Visual Templates

This document provides templates for visually presenting the XAUUSD trading strategies in the guide.

## Strategy Overview Template

Each strategy will be presented with a consistent visual layout containing the following elements:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  [STRATEGY NAME]                                        │
│                                                         │
│  ┌─────────────────┐           ┌─────────────────────┐  │
│  │                 │           │                     │  │
│  │  CONCEPT        │           │  MARKET CONTEXT     │  │
│  │  ILLUSTRATION   │           │  • Works best in:   │  │
│  │                 │           │  • Timeframes:      │  │
│  │                 │           │  • Sessions:        │  │
│  │                 │           │  • Risk level:      │  │
│  └─────────────────┘           └─────────────────────┘  │
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │                                                     ││
│  │  SETUP IDENTIFICATION                               ││
│  │  • Key pattern:                                     ││
│  │  • Entry trigger:                                   ││
│  │  • Confirmation signals:                            ││
│  │  • Invalidation criteria:                           ││
│  │                                                     ││
│  └─────────────────────────────────────────────────────┘│
│                                                         │
│  ┌─────────────────┐           ┌─────────────────────┐  │
│  │                 │           │                     │  │
│  │  ENTRY CHART    │           │  RISK MANAGEMENT    │  │
│  │  EXAMPLE        │           │  • Stop placement:  │  │
│  │                 │           │  • Target levels:   │  │
│  │                 │           │  • R:R ratio:       │  │
│  │                 │           │  • Position sizing: │  │
│  └─────────────────┘           └─────────────────────┘  │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Strategy Comparison Template

For comparing multiple strategies or variations:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  STRATEGY COMPARISON: [CATEGORY]                        │
│                                                         │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────┐ │
│  │ STRATEGY 1      │  │ STRATEGY 2      │  │STRATEGY 3 │ │
│  │ • Key concept:  │  │ • Key concept:  │  │• Key:     │ │
│  │ • Best when:    │  │ • Best when:    │  │• Best:    │ │
│  │ • Timeframes:   │  │ • Timeframes:   │  │• Time:    │ │
│  │ • Win rate:     │  │ • Win rate:     │  │• Win:     │ │
│  │ • Avg R:R:      │  │ • Avg R:R:      │  │• Avg:     │ │
│  └─────────────────┘  └─────────────────┘  └──────────┘ │
│                                                         │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────┐ │
│  │                 │  │                 │  │          │ │
│  │ EXAMPLE CHART   │  │ EXAMPLE CHART   │  │ EXAMPLE  │ │
│  │                 │  │                 │  │          │ │
│  │                 │  │                 │  │          │ │
│  └─────────────────┘  └─────────────────┘  └──────────┘ │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Trade Execution Template

For step-by-step trade execution:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  TRADE EXECUTION: [STRATEGY NAME]                       │
│                                                         │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │
│  │ STEP 1  │  │ STEP 2  │  │ STEP 3  │  │ STEP 4  │     │
│  │         │  │         │  │         │  │         │     │
│  │ Identify│  │ Confirm │  │ Wait for│  │ Execute │     │
│  │ Setup   │  │ Context │  │ Trigger │  │ Entry   │     │
│  │         │  │         │  │         │  │         │     │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │
│       │            │            │            │          │
│       ▼            ▼            ▼            ▼          │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │
│  │         │  │         │  │         │  │         │     │
│  │ CHART   │  │ CHART   │  │ CHART   │  │ CHART   │     │
│  │ EXAMPLE │  │ EXAMPLE │  │ EXAMPLE │  │ EXAMPLE │     │
│  │         │  │         │  │         │  │         │     │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Multi-Timeframe Analysis Template

For showing the same setup across different timeframes:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  MULTI-TIMEFRAME ANALYSIS: [STRATEGY NAME]              │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  HIGHER TIMEFRAME       │  │  KEY OBSERVATIONS   │   │
│  │  (4H/Daily)             │  │  • Trend direction  │   │
│  │                         │  │  • Key levels       │   │
│  │                         │  │  • Major structures │   │
│  │                         │  │  • Bias            │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  MEDIUM TIMEFRAME       │  │  KEY OBSERVATIONS   │   │
│  │  (1H/15M)               │  │  • Entry zone       │   │
│  │                         │  │  • POI details      │   │
│  │                         │  │  • Confirmation     │   │
│  │                         │  │  • Structure        │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  LOWER TIMEFRAME        │  │  KEY OBSERVATIONS   │   │
│  │  (5M/1M)                │  │  • Precise entry    │   │
│  │                         │  │  • Stop placement   │   │
│  │                         │  │  • Trigger candle   │   │
│  │                         │  │  • Timing           │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Strategy Backtesting Results Template

For presenting strategy performance data:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  BACKTESTING RESULTS: [STRATEGY NAME]                   │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  PERFORMANCE METRICS    │  │  OPTIMAL CONDITIONS │   │
│  │  • Win rate: XX%        │  │  • Best sessions:   │   │
│  │  • Avg R:R: X.X         │  │  • Best timeframes: │   │
│  │  • Profit factor: X.X   │  │  • Best market:     │   │
│  │  • Max drawdown: XX%    │  │  • Avoid when:      │   │
│  │  • Avg holding time: XH │  │                     │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │                                                     ││
│  │  EQUITY CURVE / PERFORMANCE CHART                   ││
│  │                                                     ││
│  │                                                     ││
│  │                                                     ││
│  │                                                     ││
│  └─────────────────────────────────────────────────────┘│
│                                                         │
│  ┌─────────────────────────────────────────────────────┐│
│  │                                                     ││
│  │  SAMPLE TRADES (3-5 EXAMPLES)                       ││
│  │                                                     ││
│  │                                                     ││
│  │                                                     ││
│  │                                                     ││
│  └─────────────────────────────────────────────────────┘│
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Strategy Checklist Template

For pre-trade verification:

```
┌─────────────────────────────────────────────────────────┐
│                                                         │
│  STRATEGY CHECKLIST: [STRATEGY NAME]                    │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  MARKET CONTEXT         │  │  SETUP VALIDATION   │   │
│  │  □ HTF bias aligned     │  │  □ Valid POI        │   │
│  │  □ Session appropriate  │  │  □ Clean structure  │   │
│  │  □ Volatility suitable  │  │  □ Proper candle    │   │
│  │  □ No conflicting news  │  │  □ Indicator align  │   │
│  │  □ Key levels identified│  │  □ Volume confirm   │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
│  ┌─────────────────────────┐  ┌─────────────────────┐   │
│  │                         │  │                     │   │
│  │  ENTRY PARAMETERS       │  │  RISK MANAGEMENT    │   │
│  │  □ Entry price defined  │  │  □ Stop beyond      │   │
│  │  □ Entry trigger clear  │  │    structure        │   │
│  │  □ Entry timeframe set  │  │  □ Position size    │   │
│  │  □ Entry type selected  │  │    calculated       │   │
│  │  □ Entry time window    │  │  □ R:R minimum 1:2  │   │
│  │    identified           │  │  □ Targets defined  │   │
│  └─────────────────────────┘  └─────────────────────┘   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Implementation Notes

1. Each template will be customized for specific strategies while maintaining consistent structure.

2. Actual chart examples from the collected visual materials will be integrated into these templates.

3. Color coding will be used consistently:
   - Bullish patterns/setups: Gold/Yellow
   - Bearish patterns/setups: Red
   - Neutral elements: Blue or Gray

4. All templates will include clear annotations with:
   - Arrows pointing to key elements
   - Labels for important price levels
   - Circles highlighting entry/exit points
   - Dotted lines for projections

5. Each visual template will be referenced in the corresponding text section of the guide.

These templates provide a structured framework for presenting the strategies in a visually consistent and educational manner, making complex concepts easier to understand and apply.
