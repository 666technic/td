import React from 'react';
import Link from 'next/link';

// Component for strategy card on strategy pages
const StrategyCard = ({ title, description, difficulty, timeframes, riskReward, children }) => {
  // Convert difficulty to color
  const difficultyColor = () => {
    switch (difficulty.toLowerCase()) {
      case 'beginner': return 'bg-green-100 text-green-800';
      case 'intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white shadow-md rounded-lg p-6 mb-6 border-l-4 border-yellow-500">
      <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
      
      <div className="flex flex-wrap gap-2 mb-4">
        <span className={`text-xs px-2 py-1 rounded-full ${difficultyColor()}`}>
          {difficulty}
        </span>
        <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">
          {timeframes}
        </span>
        <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-800">
          R:R {riskReward}
        </span>
      </div>
      
      <p className="text-gray-600 mb-4">{description}</p>
      
      {children}
    </div>
  );
};

export default StrategyCard;
