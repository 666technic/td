# Standard Indicators for Confluence in XAUUSD Trading

This section explores specific standard indicators that work effectively within the SMC/ICT framework for XAUUSD trading. We'll examine optimal settings, interpretation methods, and integration with core SMC/ICT concepts.

## Momentum Indicators

### Relative Strength Index (RSI)

The RSI is one of the most versatile indicators for confirming momentum shifts at key SMC/ICT levels in gold trading.

**Optimal Settings for XAUUSD:**
- Higher Timeframes (4H+): 14-period
- Medium Timeframes (15M-1H): 10-period
- Lower Timeframes (1M-5M): 7-period

**Key Interpretation Methods:**

1. **Divergence at Liquidity Sweeps**
   - Regular divergence: Price makes new high/low while RSI makes lower high/higher low
   - Hidden divergence: Price makes lower high/higher low while RSI makes higher high/lower low
   - In XAUUSD, divergence at round numbers is particularly significant
   - Most reliable when aligned with Order Blocks or Fair Value Gaps

2. **Momentum Confirmation at Order Blocks**
   - Bullish OB: Look for RSI turning upward from below 40
   - Bearish OB: Look for RSI turning downward from above 60
   - The sharper the turn, the stronger the confirmation
   - In gold markets, momentum turns tend to be more dramatic than in forex

3. **Trend Strength Assessment**
   - Bullish trend: RSI consistently above 50, making higher lows
   - Bearish trend: RSI consistently below 50, making lower highs
   - Ranging market: RSI oscillating around 50 without clear direction
   - Helps determine appropriate strategy selection for current XAUUSD conditions

**Integration with SMC/ICT Concepts:**
- Use RSI divergence to confirm potential reversals at liquidity sweeps
- Look for momentum shifts at key Order Blocks to confirm valid entries
- Confirm trend direction on higher timeframes before trading lower timeframe setups
- Use RSI to help differentiate between continuation and reversal scenarios

**XAUUSD-Specific Applications:**
- Gold tends to show clearer RSI divergence than many forex pairs
- Round number psychology in XAUUSD creates frequent divergence opportunities
- During high-volatility gold movements, RSI can remain overbought/oversold longer than expected
- RSI works particularly well for identifying exhaustion in gold trends

### MACD (Moving Average Convergence Divergence)

The MACD provides valuable insights into momentum shifts and trend strength in XAUUSD markets.

**Optimal Settings for XAUUSD:**
- Higher Timeframes (4H+): (12,26,9) standard settings
- Medium Timeframes (15M-1H): (8,17,9) for increased sensitivity
- Lower Timeframes (1M-5M): (5,13,8) for faster signals

**Key Interpretation Methods:**

1. **Histogram Shifts**
   - Early warning of momentum changes
   - Particularly useful at key SMC/ICT levels
   - In XAUUSD, histogram shifts often precede significant price movements
   - Most reliable when aligned with structural turning points

2. **Signal Line Crossovers**
   - Confirmation of momentum direction
   - Use primarily on higher timeframes for trend confirmation
   - In gold markets, crossovers at extreme MACD readings often signal significant moves
   - More reliable when occurring at Order Blocks or Fair Value Gaps

3. **Divergence Analysis**
   - Similar to RSI divergence but often provides earlier signals
   - Regular and hidden divergence principles apply
   - In XAUUSD, MACD divergence at major swing points is particularly significant
   - Most effective when confirmed by price action patterns

**Integration with SMC/ICT Concepts:**
- Use histogram shifts to confirm momentum at Order Blocks
- Look for MACD crossovers to confirm BOS (Break of Structure)
- Use divergence to identify potential reversals at liquidity levels
- Confirm trend direction on higher timeframes before trading lower timeframe setups

**XAUUSD-Specific Applications:**
- Gold's trending nature makes MACD particularly effective for trend identification
- During strong XAUUSD trends, MACD can remain in extreme territory for extended periods
- MACD histogram shifts often precede significant gold price movements by several candles
- Works exceptionally well for identifying trend exhaustion in XAUUSD

### Stochastic Oscillator

The Stochastic Oscillator is effective for identifying overbought/oversold conditions and momentum shifts in XAUUSD trading.

**Optimal Settings for XAUUSD:**
- Higher Timeframes (4H+): (14,3,3) standard settings
- Medium Timeframes (15M-1H): (10,3,3) for balanced sensitivity
- Lower Timeframes (1M-5M): (5,3,3) for faster signals

**Key Interpretation Methods:**

1. **Overbought/Oversold Conditions**
   - Overbought: Above 80 level
   - Oversold: Below 20 level
   - In XAUUSD, extreme readings at key structural levels are significant
   - Most reliable when aligned with Order Blocks or Fair Value Gaps

2. **%K/%D Crossovers**
   - Signals potential momentum shifts
   - More reliable when occurring in overbought/oversold territory
   - In gold markets, crossovers near round numbers often precede significant moves
   - Use primarily for entry timing rather than trade selection

3. **Divergence Analysis**
   - Similar principles to RSI divergence
   - Often provides earlier signals than RSI
   - In XAUUSD, stochastic divergence at major swing points is particularly significant
   - Most effective when confirmed by price action patterns

**Integration with SMC/ICT Concepts:**
- Use overbought/oversold readings to confirm potential reversals at Order Blocks
- Look for %K/%D crossovers to refine entry timing at predetermined zones
- Use divergence to identify potential reversals at liquidity levels
- Particularly effective for range-bound gold market conditions

**XAUUSD-Specific Applications:**
- Works exceptionally well during range-bound gold market conditions
- Stochastic crossovers in extreme territory often precede significant XAUUSD moves
- During strong gold trends, can remain in overbought/oversold territory for extended periods
- Particularly effective when combined with round number psychology in XAUUSD

## Volatility Indicators

### Average True Range (ATR)

The ATR is essential for managing gold's higher volatility and determining appropriate risk parameters.

**Optimal Settings for XAUUSD:**
- 14-period ATR works well across all timeframes
- Consider 10-period for more responsive readings on lower timeframes

**Key Interpretation Methods:**

1. **Stop Loss Determination**
   - Multiply current ATR by appropriate factor (typically 1-1.5)
   - Place stop beyond relevant structure but at least this distance from entry
   - In XAUUSD, higher volatility often requires wider stops than forex pairs
   - Adjust multiplier based on current market conditions

2. **Volatility Assessment**
   - Compare current ATR to historical average
   - Higher than average: Expect larger moves, adjust position sizing accordingly
   - Lower than average: Potential consolidation or pre-breakout conditions
   - In gold markets, volatility often increases before major economic releases

3. **Profit Target Projection**
   - Use ATR multiples for realistic target setting
   - Typical targets: 2-3x ATR for scalping, 3-5x ATR for intraday trading
   - In XAUUSD, targets based on structure often align with these ATR multiples
   - Helps validate structure-based targets

**Integration with SMC/ICT Concepts:**
- Use ATR to determine appropriate stop distance beyond Order Blocks
- Assess volatility conditions before trading breakouts or range strategies
- Adjust position sizing based on current volatility relative to historical norms
- Use ATR expansion/contraction to identify potential market phase changes

**XAUUSD-Specific Applications:**
- Essential for managing gold's higher volatility compared to forex pairs
- ATR expansion often precedes significant trend moves in XAUUSD
- ATR contraction frequently occurs before major breakouts in gold
- Particularly useful during high-impact economic releases affecting gold

### Bollinger Bands

Bollinger Bands help identify volatility contraction/expansion cycles and potential reversal zones in XAUUSD trading.

**Optimal Settings for XAUUSD:**
- Higher Timeframes (4H+): (20,2) standard settings
- Medium Timeframes (15M-1H): (20,2) standard settings
- Lower Timeframes (1M-5M): (20,2.5) for wider bands to account for noise

**Key Interpretation Methods:**

1. **Volatility Contraction/Expansion**
   - Narrowing bands: Decreasing volatility, potential energy building
   - Widening bands: Increasing volatility, trend likely in progress
   - In XAUUSD, contraction often precedes significant breakouts
   - Particularly noticeable before major economic releases affecting gold

2. **Band Touches as Reversal Zones**
   - Price touching or exceeding bands suggests potential reversal
   - More significant when aligned with key SMC/ICT levels
   - In gold markets, band touches at round numbers are particularly significant
   - Most reliable when confirmed by candlestick patterns

3. **Trend Direction Confirmation**
   - Price consistently above middle band: Bullish bias
   - Price consistently below middle band: Bearish bias
   - Price oscillating around middle band: Ranging conditions
   - Helps confirm the higher timeframe bias in XAUUSD

**Integration with SMC/ICT Concepts:**
- Look for Order Blocks forming near band touches
- Use band width to assess potential for breakouts at key levels
- Confirm trend direction before trading continuation setups
- Use middle band as dynamic support/resistance in trending conditions

**XAUUSD-Specific Applications:**
- Gold's volatility creates clear band expansion/contraction cycles
- Band touches at psychological round numbers often create significant reversals
- During strong trends, XAUUSD can "walk the bands" for extended periods
- Band width expansion often coincides with liquidity sweeps in gold markets

### Keltner Channels

Keltner Channels provide a more consistent volatility envelope than Bollinger Bands, particularly useful during trending XAUUSD conditions.

**Optimal Settings for XAUUSD:**
- (20,2) with ATR multiplier works well across all timeframes
- Consider (10,2) for more responsive readings on lower timeframes

**Key Interpretation Methods:**

1. **Trend Identification**
   - Price consistently above middle line: Bullish trend
   - Price consistently below middle line: Bearish trend
   - Price oscillating around middle line: Ranging conditions
   - In XAUUSD, trend identification is clearer than with Bollinger Bands

2. **Channel Breakouts**
   - Price breaking above upper channel: Strong bullish momentum
   - Price breaking below lower channel: Strong bearish momentum
   - In gold markets, channel breakouts often lead to extended moves
   - Most significant when aligned with higher timeframe structure

3. **Channel Width Assessment**
   - Widening channel: Increasing volatility, trend strength
   - Narrowing channel: Decreasing volatility, potential consolidation
   - In XAUUSD, channel width changes often precede significant market shifts
   - Helps identify potential trend exhaustion points

**Integration with SMC/ICT Concepts:**
- Use channel touches to confirm potential entries at Order Blocks
- Look for BOS (Break of Structure) coinciding with channel breakouts
- Use middle line as dynamic support/resistance in trending conditions
- Channel width helps assess appropriate stop distance for XAUUSD trades

**XAUUSD-Specific Applications:**
- More reliable than Bollinger Bands during strong gold trends
- Channel touches often align with significant Order Blocks in XAUUSD
- Channel width provides valuable context for gold's variable volatility
- Particularly effective during trending gold market conditions

## Trend Indicators

### Moving Averages

Moving averages provide dynamic support/resistance levels and trend direction confirmation in XAUUSD trading.

**Optimal Settings for XAUUSD:**
- Short-term trend: 8 EMA and 21 EMA
- Medium-term trend: 50 SMA
- Long-term trend: 200 SMA

**Key Interpretation Methods:**

1. **Moving Average Crossovers**
   - 8 EMA crossing above 21 EMA: Short-term bullish signal
   - 8 EMA crossing below 21 EMA: Short-term bearish signal
   - 50 SMA crossing above/below 200 SMA: Major trend shift (golden/death cross)
   - In XAUUSD, crossovers at key structural levels are particularly significant

2. **Dynamic Support/Resistance**
   - Price respecting moving averages as support/resistance
   - More significant when multiple MAs align at similar levels
   - In gold markets, the 50 and 200 SMAs are particularly respected
   - Often creates high-probability bounce opportunities

3. **MA Slope Analysis**
   - Steepening slope: Increasing trend momentum
   - Flattening slope: Decreasing trend momentum
   - Slope reversal: Potential trend change
   - Helps assess the strength and maturity of XAUUSD trends

**Integration with SMC/ICT Concepts:**
- Look for Order Blocks forming near key moving averages
- Use MA support/resistance to confirm potential entry zones
- MA crossovers can confirm CHoCH (Change of Character)
- MA alignment across timeframes helps confirm trend strength

**XAUUSD-Specific Applications:**
- Gold tends to respect the 50 and 200 SMAs more consistently than many forex pairs
- MA crossovers often coincide with significant trend changes in XAUUSD
- During strong trends, gold often finds support/resistance at the 21 EMA
- The 200 SMA frequently acts as a major psychological level in gold markets

### Ichimoku Cloud

The Ichimoku Cloud provides comprehensive trend analysis and potential support/resistance zones for XAUUSD trading.

**Optimal Settings for XAUUSD:**
- Standard settings (9,26,52) work well for gold across all timeframes

**Key Interpretation Methods:**

1. **Cloud Position Analysis**
   - Price above cloud: Bullish bias
   - Price below cloud: Bearish bias
   - Price inside cloud: Neutral/consolidation
   - In XAUUSD, cloud position provides reliable trend context

2. **Tenkan-sen/Kijun-sen Relationship**
   - Tenkan-sen above Kijun-sen: Bullish momentum
   - Tenkan-sen below Kijun-sen: Bearish momentum
   - Crossovers signal potential momentum shifts
   - In gold markets, these crossovers often precede significant moves

3. **Cloud Thickness and Color**
   - Thick cloud: Strong support/resistance
   - Thin cloud: Weaker support/resistance
   - Green cloud: Bullish future projection
   - Red cloud: Bearish future projection
   - Helps assess future trend strength in XAUUSD

**Integration with SMC/ICT Concepts:**
- Use cloud edges as potential support/resistance zones
- Look for Order Blocks forming near Kijun-sen
- Tenkan-sen/Kijun-sen crossovers can confirm BOS (Break of Structure)
- Cloud thickness helps assess the strength of potential reversal zones

**XAUUSD-Specific Applications:**
- Particularly effective for identifying longer-term gold trends
- Cloud support/resistance often aligns with significant XAUUSD price levels
- Chikou Span crossing price often precedes major trend changes in gold
- Future cloud projections help anticipate potential support/resistance zones

### Supertrend Indicator

The Supertrend indicator provides clear trend direction signals and dynamic stop loss levels for XAUUSD trading.

**Optimal Settings for XAUUSD:**
- Higher Timeframes (4H+): (10,3)
- Medium Timeframes (15M-1H): (10,3)
- Lower Timeframes (1M-5M): (7,3) for increased sensitivity

**Key Interpretation Methods:**

1. **Trend Direction Signals**
   - Indicator turns green: Bullish signal
   - Indicator turns red: Bearish signal
   - In XAUUSD, trend changes often align with significant structural shifts
   - Particularly reliable on higher timeframes

2. **Dynamic Stop Loss Levels**
   - Supertrend line provides trailing stop reference
   - Adjust actual stop placement based on nearby structure
   - In gold markets, slightly wider stops often necessary due to volatility
   - Helps maintain position through normal market noise

3. *
(Content truncated due to size limit. Use line ranges to read in chunks)