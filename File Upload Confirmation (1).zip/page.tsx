import Layout from '@/components/Layout';
import Image from 'next/image';

export default function Home() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-yellow-600 mb-6">The Definitive SMC & ICT Guide for XAUUSD Trading</h1>
        
        <div className="bg-white shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Introduction</h2>
          
          <p className="mb-4">
            This comprehensive guide represents the culmination of years of research, analysis, and practical application of Smart Money Concepts (SMC) and Inner Circle Trader (ICT) methodologies specifically tailored for XAUUSD (Gold) trading. Whether you're focusing on scalping opportunities that unfold in minutes or intraday positions that develop over hours, this resource is designed to transform your understanding and execution of gold trading.
          </p>
          
          <p className="mb-4">
            Gold has long been revered as both a safe-haven asset and a dynamic trading vehicle, offering unique characteristics that differentiate it from forex pairs or equity indices. Its distinct volatility patterns, liquidity profiles, and sensitivity to global economic factors create both challenges and opportunities for traders. By applying the sophisticated frameworks of SMC and ICT to this specific instrument, we unlock powerful insights that generic trading approaches simply cannot provide.
          </p>
          
          <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 my-6">
            <p className="font-semibold">Why SMC & ICT for Gold Trading?</p>
            <p>These methodologies excel at identifying the footprints of institutional activity—the "smart money" that truly moves markets. Gold, with its significant institutional participation and clear technical patterns, responds exceptionally well to these analytical frameworks.</p>
          </div>
          
          <p className="mb-4">
            This guide is structured to build your knowledge progressively, beginning with foundational concepts and terminology before advancing to sophisticated strategies and execution frameworks. Each section builds upon the previous, creating a comprehensive system rather than a collection of disconnected techniques.
          </p>
          
          <h3 className="text-xl font-semibold text-gray-700 mt-8 mb-4">How to Use This Guide</h3>
          
          <p className="mb-4">
            While you may be tempted to skip directly to the strategy sections, we strongly recommend working through this guide sequentially. The early conceptual foundations establish the critical thinking framework necessary to apply the strategies effectively. Without understanding market structure, liquidity concepts, and points of interest identification, the strategies will lack context and precision.
          </p>
          
          <p className="mb-4">For optimal results:</p>
          
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li>Study the concepts in Part 1 until they become second nature</li>
            <li>Understand how indicators serve as confirmation tools rather than primary signals</li>
            <li>Practice identifying the setups in the strategy playbook on historical charts before live trading</li>
            <li>Implement the risk management and psychological frameworks from the beginning</li>
          </ul>
          
          <p className="mb-6">
            This guide emphasizes practical application over theory. Each concept is illustrated with real XAUUSD chart examples, and each strategy includes detailed entry criteria, stop placement guidelines, and target selection methods. The visual templates provide clear frameworks for consistent analysis and execution.
          </p>
          
          <div className="bg-gray-50 border border-gray-200 p-4 text-sm text-gray-600 italic rounded">
            <p><strong>Disclaimer:</strong> Trading involves significant risk of loss and is not suitable for all investors. Past performance is not indicative of future results. The information in this guide is for educational purposes only and should not be construed as financial advice. Always conduct your own analysis and consider your financial position before trading.</p>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Guide Overview</h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-600 mb-2">Part 1: The SMC & ICT Encyclopedia</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li>Core Terminology Glossary</li>
                <li>Market Structure Mastery</li>
                <li>Liquidity Concepts Deep Dive</li>
                <li>Point of Interest (POI) Identification</li>
                <li>Advanced ICT Concepts</li>
                <li>Multi-Timeframe Analysis Protocol</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-600 mb-2">Part 2: Indicator Synergy</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li>The Role of Indicators in SMC/ICT</li>
                <li>Standard Indicators for Confluence</li>
                <li>Lux Algo Indicator Suite</li>
                <li>Other Potential Confirmatory Tools</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-600 mb-2">Part 3: Strategy Playbook</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li>Top 10 XAUUSD Scalping Strategies</li>
                <li>Top 10 XAUUSD Intraday Strategies</li>
                <li>Strategy Templates with Visual Examples</li>
              </ul>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-600 mb-2">Part 4: Execution, Risk, & Mindset</h3>
              <ul className="list-disc pl-6 space-y-1">
                <li>Pre-Trade Checklist</li>
                <li>XAUUSD Specific Risk Management</li>
                <li>Psychological Edge</li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Featured Concept: Order Blocks & Fair Value Gaps</h2>
          
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <div className="md:w-1/2">
              <Image 
                src="/images/fair_value_gap_example.png" 
                alt="Fair Value Gap Example" 
                width={500} 
                height={300}
                className="rounded-lg shadow-md"
              />
              <p className="text-sm text-center text-gray-600 mt-2">Example of a Fair Value Gap in XAUUSD</p>
            </div>
            
            <div className="md:w-1/2">
              <p className="mb-4">
                Order Blocks and Fair Value Gaps are two of the most powerful concepts in the SMC and ICT methodologies. They represent areas where institutional activity has created imbalances in the market, which often serve as magnets for price in the future.
              </p>
              <p>
                Explore the detailed sections on these concepts to learn how to identify, validate, and trade these high-probability zones in the XAUUSD market.
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
