"use client";

import React, { useState, useEffect } from 'react';

// Component for glossary term tooltip system
const GlossaryTooltip = ({ term, definition, children }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [tooltipRef, setTooltipRef] = useState(null);

  const showTooltip = (e) => {
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    setPosition({
      top: rect.bottom + window.scrollY,
      left: rect.left + window.scrollX
    });
    setIsVisible(true);
  };

  const hideTooltip = () => {
    setIsVisible(false);
  };

  // Handle clicks outside the tooltip to close it
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (tooltipRef && !tooltipRef.contains(event.target) && isVisible) {
        hideTooltip();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [tooltipRef, isVisible]);

  return (
    <span className="relative inline">
      <a 
        href="#" 
        onClick={showTooltip}
        onMouseEnter={showTooltip}
        onMouseLeave={hideTooltip}
        className="text-yellow-600 border-b border-dashed border-yellow-400 hover:text-yellow-700"
      >
        {children || term}
      </a>
      
      {isVisible && (
        <div 
          ref={setTooltipRef}
          className="absolute z-50 bg-white shadow-lg rounded-md p-3 max-w-xs border border-gray-200"
          style={{
            top: `${position.top}px`,
            left: `${position.left}px`,
          }}
        >
          <h4 className="font-bold text-yellow-600 mb-1">{term}</h4>
          <p className="text-sm text-gray-700">{definition}</p>
        </div>
      )}
    </span>
  );
};

export default GlossaryTooltip;
