# Point of Interest (POI) Identification & Validation for XAUUSD Trading

Points of Interest (POIs) are specific price zones where smart money is likely to interact with the market, creating trading opportunities. This section explores how to identify, validate, and trade various types of POIs in XAUUSD markets.

## Order Blocks (OBs): The Foundation of SMC/ICT Trading

Order Blocks represent zones where institutional orders were placed, visible as the last opposing candle before a strong move. These zones act as magnets for price and often provide support/resistance when retested.

### Defining Valid Order Blocks in XAUUSD

Not all candles preceding strong moves qualify as valid Order Blocks. Understanding the specific criteria is essential for accurate identification.

**Essential Criteria for Valid Order Blocks:**

1. **Must Take Liquidity + Create Imbalance/FVG:**
   - A valid OB must precede a move that takes out liquidity (sweeps highs/lows)
   - The move must create an imbalance or Fair Value Gap
   - This combination indicates institutional participation
   - In XAUUSD, these moves are often more pronounced due to gold's volatility

2. **Candle Characteristics:**
   - Typically has a large body relative to surrounding candles
   - Often has a wick in the direction of the subsequent move
   - Usually closes near the opposite extreme from the subsequent move
   - In XAUUSD, valid OBs often form during high-volume periods (London/NY sessions)

3. **Context Considerations:**
   - Must form at a logical turning point in the market structure
   - Should align with higher timeframe structure for increased validity
   - More significant when formed after liquidity sweeps
   - In gold markets, more reliable when formed around key economic releases

### Decisional vs. Extreme Order Blocks

Order Blocks can be categorized based on their position within the market structure, with different implications for trading.

**Decisional Order Blocks:**
- Form within the body of a previous candle
- Represent areas where smart money made a decision to reverse the market
- Typically provide stronger support/resistance
- Often form after consolidation periods in XAUUSD
- Higher probability of holding when retested

**Extreme Order Blocks:**
- Form at the extremes of a move (swing highs/lows)
- Represent the final push before a reversal
- May be less reliable than decisional OBs
- In XAUUSD, often form during volatile price spikes
- May require confirmation from other factors

### Mitigation vs. Breaker Blocks

Understanding how Order Blocks evolve after being retested is crucial for anticipating price behavior.

**Mitigation Process:**
- Occurs when price returns to an Order Block
- The OB "delivers" its orders, potentially causing a reaction
- Partial mitigation: Price enters the OB but doesn't fully traverse it
- Full mitigation: Price moves through the entire OB
- In XAUUSD, mitigation often occurs more quickly than in forex pairs due to higher volatility

**Breaker Blocks:**
- Formed when an OB is fully mitigated and then broken
- The broken OB flips from support to resistance (or vice versa)
- Creates high-probability continuation opportunities
- XAUUSD breaker blocks often lead to extended moves
- Particularly powerful when they align with higher timeframe structure

### XAUUSD Examples of Valid/Invalid Order Blocks

[Note: This section will include annotated XAUUSD chart examples showing valid and invalid Order Blocks]

## Fair Value Gaps (FVGs) / Imbalances

Fair Value Gaps represent significant imbalances in the market where price moved so quickly that no trading occurred in a specific range. These gaps act as magnets for price and often get filled in future price action.

### Identification and Significance

FVGs are relatively easy to identify but understanding their significance requires deeper analysis.

**Identification Criteria:**
- Gap between the bodies of candles (not just wicks)
- Created by strong momentum moves
- No overlap between the candles creating the gap
- In XAUUSD, typically larger and more frequent than in forex pairs
- Often form during high-impact news affecting gold

**Significance Factors:**
- Size of the gap (larger gaps are more significant)
- Timeframe (higher timeframe FVGs carry more weight)
- Context (FVGs at structural turning points are more significant)
- Volume during formation (higher volume creates more significant FVGs)
- In gold markets, FVGs formed during major economic releases tend to be more reliable

### FVGs as Draws on Liquidity or Entry Points

FVGs can function in two primary ways, depending on market context.

**As Liquidity Draws:**
- Price often returns to fill FVGs
- Institutions use these returns to enter positions
- The speed and manner of filling can indicate institutional intent
- In XAUUSD, FVGs are filled more reliably than in many other markets
- Particularly true for FVGs formed during high-volatility events

**As Entry Points:**
- FVGs can provide optimal entry zones for trend continuation
- Especially valid when aligned with the higher timeframe trend
- Often provide better risk-reward than waiting for deeper retracements
- In gold trading, FVGs in the direction of the trend offer high-probability entries
- Particularly effective during strong trend days

### Efficient vs. Inefficient Price Action

The concept of efficiency helps determine which FVGs are likely to be filled and which might be skipped.

**Efficient Price Action:**
- Direct, purposeful movement with minimal retracement
- Creates FVGs that may not get filled for extended periods
- Indicates strong institutional commitment to direction
- Common in XAUUSD during trending markets
- Often seen after breakouts from significant levels

**Inefficient Price Action:**
- Choppy, overlapping candles with frequent reversals
- Creates FVGs that tend to be filled quickly
- Indicates lack of clear institutional direction
- Common in XAUUSD during consolidation phases
- Often seen during low-liquidity periods (Asian session)

### High Volume Imbalance (HVI)

A specialized type of FVG that forms with notably high volume, indicating stronger institutional participation.

**Identification:**
- Standard FVG criteria plus significantly higher volume
- Often forms after major news events affecting gold
- Creates larger, more significant gaps
- Note: Volume data may not be available on all XAUUSD platforms
- Can be inferred from candle size and market conditions when volume data is unavailable

**Trading Applications:**
- HVIs are more likely to be respected than standard FVGs
- Provide stronger support/resistance when tested
- Often lead to stronger reactions when filled
- In XAUUSD, particularly reliable after Fed announcements, NFP, or inflation data
- Create high-probability reversal opportunities when combined with other SMC concepts

## Institutional Funding Candles (IFC)

Institutional Funding Candles represent periods where smart money is actively building positions before a planned move. Identifying these candles helps anticipate future price direction.

### Definition and Role in POI Selection

**Characteristics of IFCs:**
- Typically larger than surrounding candles
- Often have higher volume (when visible)
- Usually close near their extremes
- Frequently precede strong momentum moves
- In XAUUSD, often form during the early phases of London or NY sessions

**Role in Trading:**
- IFCs often form the basis of significant Order Blocks
- Help identify which OBs are likely to be more powerful
- Provide context for understanding institutional intent
- In gold markets, particularly important before major economic catalysts
- Help differentiate between random price movements and planned institutional campaigns

### XAUUSD Examples

[Note: This section will include annotated XAUUSD chart examples showing Institutional Funding Candles and their subsequent price action]

## Rejection Blocks

Rejection Blocks represent areas where price showed strong rejection, indicating institutional defense of a level. These blocks provide valuable insights into institutional intent and create trading opportunities.

### Definition and Use Cases

**Characteristics:**
- Strong rejection candle with a long wick
- Closes near the opposite extreme from the wick
- Often forms after liquidity sweeps
- In XAUUSD, typically more dramatic than in forex pairs
- Frequently occurs at round numbers in gold markets

**Trading Applications:**
- Provides high-probability reversal opportunities
- Often marks the end of pullbacks in trending markets
- Can signal the beginning of new trends when formed at structural extremes
- In gold trading, particularly effective when aligned with session transitions
- Creates clear risk parameters for trade management

### XAUUSD-Specific Considerations

Gold markets exhibit unique characteristics that affect Rejection Block formation and significance:

1. **Volatility Impact:**
   - XAUUSD's higher volatility creates more dramatic rejection candles
   - Requires slightly wider stop placement than forex pairs
   - Often leads to stronger follow-through after rejection

2. **Round Number Significance:**
   - Rejection Blocks at round numbers ($1900, $1950, etc.) carry extra weight
   - Often defended more aggressively by institutions
   - Create some of the most reliable reversal opportunities

3. **News Reaction:**
   - Gold's sensitivity to economic data creates powerful rejection blocks after news
   - Post-news rejection blocks often lead to extended moves
   - Particularly significant after Fed-related announcements

## Order Flow (OF)

Order Flow analysis helps determine which side (bulls or bears) is in control of the market, providing context for all other SMC/ICT concepts.

### Bullish/Bearish Order Flow

**Bullish Order Flow Characteristics:**
- Higher highs and higher lows in market structure
- Stronger bullish candles than bearish candles
- Bearish candles quickly reversed by bullish pressure
- Bullish candles close near their highs
- In XAUUSD, often accompanied by USD weakness

**Bearish Order Flow Characteristics:**
- Lower highs and lower lows in market structure
- Stronger bearish candles than bullish candles
- Bullish candles quickly reversed by bearish pressure
- Bearish candles close near their lows
- In XAUUSD, often accompanied by USD strength

### Softened vs. Unsoftened Order Flow

The concept of "softening" helps determine the strength of potential reactions at key levels.

**Unsoftened Order Flow:**
- Price has not yet tested a significant level
- First tests of levels tend to produce stronger reactions
- Creates higher-probability trading opportunities
- In gold markets, unsoftened levels often lead to sharp reversals
- Particularly important at psychological round numbers

**Softened Order Flow:**
- Price has already tested a level one or more times
- Subsequent tests typically produce weaker reactions
- May require additional confirmation for trade entries
- In XAUUSD, even softened levels can produce strong reactions during high-impact events
- Multiple tests without breaking often lead to eventual breakouts

### Role in Narrative Development

Order Flow analysis helps construct a coherent narrative about institutional intent, essential for anticipating future price movements.

**Narrative Components:**
- Identification of the controlling side (bulls or bears)
- Recognition of shift points where control changes
- Understanding of institutional objectives (liquidity hunting, accumulation, distribution)
- In XAUUSD, narratives often align with broader economic themes
- Particularly important during trending gold markets

**Practical Application:**
- Use OF analysis to confirm or reject potential trade setups
- Avoid counter-trend trades unless clear OF shift is evident
- Align entries with the dominant OF direction
- In gold trading, pay special attention to OF shifts after major economic releases
- Use OF context to determine appropriate risk parameters

## High-Probability POI Selection

With multiple POIs potentially present on a chart, knowing how to select the highest-probability ones is crucial for trading success.

### Secrets/Criteria for Choosing POIs Most Likely to Hold

**Multi-Factor Confluence:**
- POIs aligned with multiple SMC/ICT concepts have higher probability
- Example: An Order Block that is also at a key liquidity level and aligns with a Fair Value Gap
- In XAUUSD, confluence with round numbers adds significant weight
- POIs with at least 3 confluence factors offer the highest probability

**Timeframe Alignment:**
- POIs that align across multiple timeframes have higher validity
- Higher timeframe POIs take precedence over lower timeframe ones
- Ideal scenario: HTF structure + MTF POI + LTF entry trigger
- Particularly important in volatile XAUUSD markets
- Creates clearer risk parameters for trade management

**Market Context:**
- POIs in the direction of the dominant trend have higher probability
- Counter-trend POIs require stronger confirmation
- Consider broader market conditions (risk sentiment, USD strength/weakness)
- In gold markets, consider correlation with other markets (USD, bonds, equities)
- Pay attention to upcoming economic events that might affect gold

**Historical Respect:**
- POIs that have been respected in the past are more likely to be respected again
- Look for previous reactions at similar price levels
- More significant when respected across multiple timeframes
- In XAUUSD, historical levels tend to be respected more consistently than in many forex pairs
- Particularly true for major swing points on daily/weekly charts

### XAUUSD-Specific Considerations

Gold markets have unique characteristics that affect POI selection and probability:

1. **Volatility Management:**
   - XAUUSD's higher volatility requires slightly wider zones for POIs
   - Typically 5-10 pips wider than comparable forex setups
   - Helps avoid premature stop-outs during normal price fluctuations

2. **Session Awareness:**
   - POIs tested during their "home" session tend to be more reliable
   - Example: London session POIs tested during London hours
   - Creates session-specific trading opportunities in XAUUSD
   - Particularly important for intraday trading strategies

3. **Economic Calendar Integration:**
   - Gold is highly sensitive to specific economic releases
   - POIs tested during/after relevant news have different characteristics
   - Pre-news POIs often get violated during the news event
   - Post-news POIs tend to be more reliable for subsequent price action

4. **Correlation Awareness:**
   - Consider USD strength/weakness when evaluating XAUUSD POIs
   - Strong inverse correlation between gold and USD
   - POIs that align with USD technical levels have higher probability
   - Creates opportunities for confirmation from multiple markets

Understanding how to identify, validate, and select high-probability Points of Interest is essential for successful XAUUSD trading using SMC and ICT methodologies. By mastering these concepts and applying them specifically to gold markets, you'll develop the ability to identify optimal trade locations with favorable risk-reward profiles.
