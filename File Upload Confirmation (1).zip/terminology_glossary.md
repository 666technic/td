# Core Terminology Glossary: SMC & ICT Concepts for XAUUSD Trading

This glossary provides concise explanations of key Smart Money Concepts (SMC) and Inner Circle Trader (ICT) terminology that forms the foundation of our XAUUSD trading approach. Understanding these terms is essential before proceeding to the strategy sections.

## Foundational Concepts

### SMC (Smart Money Concepts)
A trading methodology focused on identifying and following the actions of institutional traders (smart money) by analyzing price action, market structure, and order flow. SMC aims to align retail traders with institutional movements rather than fighting against them.

### ICT (Inner Circle Trader)
A trading methodology developed by Michael J. Huddleston that evolved from SMC principles, focusing on specific concepts like order blocks, fair value gaps, and optimal trade entries. ICT provides a structured framework for understanding institutional order flow.

### Smart Money
Refers to institutional traders, banks, hedge funds, and other large financial entities that have the capital and information advantage to influence market movements. Their actions create the patterns and structures we identify through SMC/ICT analysis.

## Market Structure Concepts

### BOS (Break of Structure)
Occurs when price breaks above a previous high (in a downtrend) or below a previous low (in an uptrend), signaling a potential change in trend direction. In XAUUSD trading, BOS is a critical concept for identifying trend reversals and continuation opportunities.

### CHoCH (Change of Character)
Follows a BOS and occurs when price creates a higher high and higher low (in a new uptrend) or lower high and lower low (in a new downtrend), confirming the trend change. CHoCH provides stronger confirmation than BOS alone.

### HTF/LTF (Higher Timeframe/Lower Timeframe)
Refers to the practice of analyzing multiple timeframes, with HTF providing the overall bias and LTF used for precise entries. For XAUUSD scalping, HTF might be 15m/1h while LTF would be 1m/5m.

### Strong vs. Weak Highs/Lows
Strong highs/lows have multiple rejections and often form after significant momentum, making them more reliable levels. Weak highs/lows form with little momentum and are more likely to be broken. XAUUSD tends to form clear strong and weak levels due to its volatility.

## Liquidity Concepts

### Liquidity
Price levels where a concentration of stop orders exists, often at significant highs, lows, or round numbers. Smart money targets these levels to fill their positions before moving price in the intended direction.

### EQH/EQL (Equal High/Equal Low)
Occurs when price creates two or more highs/lows at the same level, creating a concentration of stop orders. These equal levels are prime liquidity targets in XAUUSD trading.

### Liquidity Void
An area on the chart where little trading activity has occurred, creating a vacuum that price tends to move through quickly once entered. These voids often appear after news events in XAUUSD.

### Sweep
The action of price briefly pushing beyond a significant high/low to trigger stop orders (accessing liquidity) before reversing. Gold markets frequently exhibit sweeps during session transitions.

### IDM (Inducement)
A price move designed to encourage traders to enter in the wrong direction, creating liquidity that smart money can use to enter their positions. Inducement is often seen before major XAUUSD moves.

### SMT (Smart Money Trap)
A false breakout or breakdown designed to trap retail traders on the wrong side of the market before the actual move occurs. XAUUSD is notorious for these traps around key economic releases.

## Point of Interest (POI) Concepts

### POI (Point of Interest)
Any significant level on the chart where smart money is likely to interact with price, including order blocks, fair value gaps, and liquidity levels. POIs form the basis for trade entries in SMC/ICT methodology.

### OB (Order Block)
A candle or group of candles where significant orders were placed by smart money, often visible as the last opposing candle before a strong move. Order blocks serve as magnets for price and often provide support/resistance when retested.

### Mitigation Block
An order block that has been partially filled but still contains unfilled orders, making it a weaker but still valid POI. These are common in XAUUSD during consolidation phases.

### Breaker Block
An order block that has been fully mitigated (price has returned to it) and then broken through, causing it to flip from support to resistance or vice versa. Breaker blocks provide strong levels for continuation trades.

### FVG (Fair Value Gap)
A significant imbalance in the market represented by a gap between candle bodies that was created by a strong move. FVGs act as magnets for price and often get filled in future price action. XAUUSD typically forms clear FVGs during high-volatility periods.

### IMB (Imbalance)
Similar to FVG but specifically referring to a gap between the wicks of candles rather than bodies. Imbalances represent areas where price moved so quickly that no trading occurred.

### IFC (Institutional Funding Candle)
A candle with high volume that precedes a significant move, indicating institutional positioning before a planned move. These candles often form the basis of order blocks.

### Rejection Block
A candle or zone that shows strong rejection of price, indicating smart money defending a level. These often form after liquidity sweeps in XAUUSD.

## Advanced ICT Concepts

### PD Array (Premium/Discount Array)
A range between a premium price (high) and discount price (low) where smart money accumulates positions. Using Fibonacci tools (particularly the 0.5 level) helps identify these arrays in XAUUSD.

### OTE (Optimal Trade Entry)
Specific Fibonacci levels (typically 61.8%, 70.5%, or 79%) within a PD array that offer the best risk-to-reward for entries. OTE is a core concept for precision entries in XAUUSD trading.

### Killzones
Specific time windows during trading sessions (Asian, London, New York) when institutional activity increases, creating high-probability trading opportunities. XAUUSD has distinct behavior patterns during each killzone.

### PO3 (Power of 3) / AMD
Represents the three phases of institutional trading: Accumulation (building positions), Manipulation (triggering retail stops), and Distribution (offloading positions to retail traders). This cycle repeats in XAUUSD across multiple timeframes.

### Displacement
A powerful, momentum-based move in price that creates significant imbalances and often indicates institutional participation. Gold is known for strong displacement moves, especially during major economic announcements.

### Order Flow (OF)
The analysis of buying and selling pressure through price action, helping to determine which side (bulls or bears) is in control. Bullish OF shows stronger buying pressure, while bearish OF indicates stronger selling pressure.

### Softened vs. Unsoftened
Refers to whether a level has been tested before. Unsoftened levels have not been tested and tend to provide stronger reactions, while softened levels have been tested and may provide weaker reactions.

## Practical Application Terms

### Confirmation
Additional evidence that supports a trading decision, such as a specific candle pattern, indicator signal, or price action behavior at a key level. Confirmation is essential for high-probability XAUUSD trades.

### Confluence
The alignment of multiple SMC/ICT concepts at or near the same price level, increasing the probability of a successful trade. Trading with confluence is a core principle of this methodology.

### Entry Trigger
The specific price action or indicator signal that initiates trade execution after all analysis and confirmation criteria have been met. Clear entry triggers are essential for disciplined XAUUSD trading.

### Stop Run
A price move specifically designed to trigger stop-loss orders before reversing in the original direction. XAUUSD is particularly prone to stop runs during low-liquidity periods.

### Liquidity Engineering
The deliberate creation of liquidity pools by smart money through price manipulation, setting up future trading opportunities. Understanding this concept helps anticipate XAUUSD movements.

This glossary serves as a reference throughout the guide. Each concept will be explored in greater depth with XAUUSD-specific examples in the following sections.
