# Market Structure Mastery for XAUUSD Trading

Market structure forms the foundation of all SMC and ICT analysis. Before identifying specific entry points or trading setups, you must first understand the overall structure of the market. This section will teach you how to analyze market structure specifically for XAUUSD trading.

## Pulse & Correction Waves in Gold Markets

Gold price movement, like all markets, follows a pattern of pulse (expansion) waves and correction waves. Understanding these waves is crucial for identifying the market's current phase and anticipating future movements.

### Pulse Waves
Pulse waves represent strong directional movement, often driven by institutional participation. In XAUUSD charts, these appear as a series of strong candles in one direction with minimal pullbacks.

**Identification Rules for Pulse Waves in XAUUSD:**
- Series of candles (typically 3 or more) moving strongly in one direction
- Candles have large bodies and small wicks in the direction of the move
- Limited overlap between consecutive candles
- Often accompanied by increased volume (though not visible on all platforms)
- Frequently occur during major economic announcements affecting gold

**XAUUSD-Specific Characteristics:**
Gold tends to produce cleaner and more extended pulse waves than many forex pairs, particularly during high-volatility periods such as NFP releases, Fed announcements, or geopolitical events. These pulse waves often create significant fair value gaps and order blocks that become key trading levels later.

### Correction Waves
Correction waves represent counter-trend movements that retrace a portion of the preceding pulse wave. These corrections provide the entry opportunities for trading in the direction of the larger trend.

**Identification Rules for Correction Waves in XAUUSD:**
- Price retraces against the preceding pulse wave
- Often moves at a slower pace than the pulse wave
- Typically retraces to key Fibonacci levels (38.2%, 50%, 61.8%)
- Usually has more overlap between consecutive candles
- May form patterns like flags or wedges

**XAUUSD-Specific Characteristics:**
Gold corrections tend to be more volatile than many other markets, sometimes featuring sharp spikes that can prematurely stop out trades with tight stop losses. This characteristic makes proper stop placement particularly important when trading XAUUSD corrections.

## Validating BOS & CHoCH in XAUUSD

Break of Structure (BOS) and Change of Character (CHoCH) are critical concepts for identifying trend changes in XAUUSD. However, not all apparent breaks are valid, and understanding the specific rules for validation is essential.

### Break of Structure (BOS)

A Break of Structure occurs when price breaks above a previous significant high (in a downtrend) or below a previous significant low (in an uptrend), signaling a potential trend change.

**Rules for Validating BOS in XAUUSD:**

1. **Candle Close vs. Wick Rule:**
   - For a valid bullish BOS: The closing price must be above the previous significant high, not just the wick
   - For a valid bearish BOS: The closing price must be below the previous significant low, not just the wick
   - XAUUSD Exception: During high-volatility events, a strong wick that exceeds the previous high/low by at least 10 pips can sometimes be considered a valid BOS if followed by strong continuation

2. **Momentum Consideration:**
   - A valid BOS should show momentum in the new direction
   - Look for larger-than-average candles breaking the structure
   - XAUUSD typically shows clearer momentum on BOS due to its volatility

3. **HTF Alignment:**
   - A BOS on a lower timeframe should align with the structure on higher timeframes for increased validity
   - Example: A 5-minute BOS is more reliable if it also represents a significant level on the 15-minute or 1-hour chart

4. **Role of IDM (Inducement):**
   - A valid BOS often follows inducement in the opposite direction
   - Example: Before a bullish BOS, price may make a final low to induce shorts before breaking higher
   - This pattern is particularly common in XAUUSD during session transitions

### Change of Character (CHoCH)

A Change of Character confirms a BOS by establishing a new market structure. In an uptrend, this means creating a higher high and higher low; in a downtrend, it means creating a lower low and lower high.

**Rules for Validating CHoCH in XAUUSD:**

1. **Sequence Requirement:**
   - Bullish CHoCH: Must have BOS → Higher High → Higher Low sequence
   - Bearish CHoCH: Must have BOS → Lower Low → Lower High sequence
   - All components must be clearly identifiable on the chart

2. **Strength Assessment:**
   - The new high/low created after the BOS should exceed the previous high/low by a significant margin
   - For XAUUSD, a minimum of 10-15 pips is recommended to filter out noise
   - The subsequent pullback should not exceed the origin of the BOS

3. **Time Consideration:**
   - A valid CHoCH should not take too long to form after the BOS
   - For XAUUSD, this typically means within 5-10 candles on the timeframe being analyzed
   - Delayed CHoCH formation may indicate weakness in the new trend

### XAUUSD Chart Examples: Valid vs. Invalid Breaks

[Note: This section will include annotated XAUUSD chart examples showing valid and invalid BOS/CHoCH scenarios]

## Strong vs. Weak Highs/Lows in Gold Trading

Not all highs and lows are created equal. Understanding the difference between strong and weak highs/lows is crucial for anticipating which levels will hold and which will break.

### Strong Highs/Lows

Strong highs/lows typically form after significant momentum and often represent key institutional levels. These levels are more likely to hold when retested.

**Characteristics of Strong Highs/Lows in XAUUSD:**
- Form after extended momentum moves
- Often have multiple rejections at or near the same level
- Create clear swing points on higher timeframes
- Usually have larger candles leading into the high/low
- Often coincide with round numbers in gold (e.g., $1900, $1950)
- May form after significant news events affecting gold

**Trading Implications:**
- Strong highs/lows make better targets for take profits
- When broken, they often lead to significant continuation
- Provide more reliable support/resistance when retested
- Often become liquidity zones that institutions target

### Weak Highs/Lows

Weak highs/lows form with little momentum and are more likely to be broken when retested. They often represent temporary pauses rather than significant reversals.

**Characteristics of Weak Highs/Lows in XAUUSD:**
- Form after weak momentum or during consolidation
- Often have small bodies and large wicks
- May not be visible on higher timeframes
- Frequently occur during low-volume periods
- Often form during the Asian session in gold markets
- May appear during pre-announcement consolidation

**Trading Implications:**
- Weak highs/lows are more likely to be broken
- Provide less reliable support/resistance
- Better used for continuation trades rather than reversals
- Stop losses placed beyond weak highs/lows are more likely to be triggered

### XAUUSD-Specific Considerations

Gold markets have unique characteristics that affect the formation and significance of highs and lows:

1. **Session Influence:**
   - Highs/lows formed during the New York session tend to be stronger due to higher liquidity
   - Asian session highs/lows are often weaker and more likely to be broken during London/NY sessions
   - London session opens frequently create significant highs/lows in XAUUSD

2. **Economic Data Impact:**
   - Highs/lows formed after major economic releases affecting gold (inflation data, Fed decisions) tend to be stronger
   - Pre-announcement highs/lows are often weaker and targeted for liquidity

3. **Round Number Effect:**
   - XAUUSD shows strong respect for psychological round numbers ($1800, $1850, etc.)
   - Highs/lows near these levels tend to be stronger than those at random price points

## Internal vs. External Range Liquidity

Understanding how liquidity functions within and outside of ranges is crucial for anticipating price movements in XAUUSD.

### Internal Range Liquidity

Internal range liquidity refers to stop orders placed within an established trading range, often at support and resistance levels within the range.

**Characteristics in XAUUSD:**
- Forms at swing highs and lows within the range
- Often targeted during range-bound conditions
- Typically smaller liquidity pools compared to range boundaries
- May be targeted before a range breakout occurs
- Common during Asian session consolidation in gold

**Trading Applications:**
- Can provide scalping opportunities within the range
- Watch for sweeps of internal liquidity before range continuation
- Internal liquidity sweeps often precede range expansion

### External Range Liquidity

External range liquidity refers to stop orders placed beyond the boundaries of an established trading range, typically stop losses from traders expecting the range to continue.

**Characteristics in XAUUSD:**
- Forms above range highs (sell stops from short sellers) and below range lows (buy stops from long traders)
- Represents larger liquidity pools than internal liquidity
- Often targeted before major trend moves
- Frequently swept during high-impact news events affecting gold
- More significant on higher timeframes

**Trading Applications:**
- External liquidity sweeps often precede trend continuation
- False breakouts that sweep external liquidity provide high-probability reversal opportunities
- The distance price travels after sweeping external liquidity indicates the strength of the subsequent move

### XAUUSD Range Behavior Patterns

Gold exhibits specific range behavior patterns that traders can exploit:

1. **Asian Range Formation:**
   - XAUUSD often forms tight ranges during the Asian session
   - These ranges frequently establish the internal liquidity for the London session
   - The boundaries of Asian ranges are common targets during London opening hours

2. **Pre-News Consolidation:**
   - Before major gold-impacting news, XAUUSD often forms tight ranges
   - External liquidity beyond these ranges is frequently targeted after the news release
   - The direction of the liquidity sweep often indicates the short-term trend direction

3. **Weekly Range Considerations:**
   - XAUUSD tends to respect weekly ranges more than many forex pairs
   - Weekly highs and lows create significant external liquidity
   - Month-end and quarter-end periods often see sweeps of multi-week ranges

Understanding market structure in XAUUSD trading is not just theoretical—it forms the practical foundation for all trading decisions. By mastering the concepts of pulse and correction waves, validating BOS and CHoCH, distinguishing between strong and weak highs/lows, and understanding range liquidity dynamics, you'll develop the structural awareness needed for successful gold trading using SMC and ICT principles.
