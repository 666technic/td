# Multi-Timeframe Analysis Protocol for XAUUSD Trading

Multi-timeframe analysis is essential for successful XAUUSD trading using SMC and ICT methodologies. This section outlines a structured approach to analyzing gold across multiple timeframes to identify high-probability trading opportunities.

## The Timeframe Hierarchy for XAUUSD

Understanding the relationship between timeframes helps establish a coherent trading approach. For XAUUSD trading, we recommend the following hierarchy:

### For Scalping (Short-Term Trading)
- **Higher Timeframe (HTF)**: 1-hour or 4-hour
- **Medium Timeframe (MTF)**: 15-minute
- **Lower Timeframe (LTF)**: 1-minute or 5-minute
- **Execution Timeframe (ETF)**: 1-minute

### For Intraday Trading
- **Higher Timeframe (HTF)**: 4-hour or Daily
- **Medium Timeframe (MTF)**: 1-hour
- **Lower Timeframe (LTF)**: 15-minute
- **Execution Timeframe (ETF)**: 5-minute

### For Swing Trading
- **Higher Timeframe (HTF)**: Daily or Weekly
- **Medium Timeframe (MTF)**: 4-hour
- **Lower Timeframe (LTF)**: 1-hour
- **Execution Timeframe (ETF)**: 15-minute

## The Top-Down Analysis Process

A systematic approach to multi-timeframe analysis ensures comprehensive market understanding and precise trade execution.

### Step 1: Higher Timeframe (HTF) Analysis

The HTF provides the overall bias and context for all trading decisions.

**Key Elements to Identify:**
- Overall market structure (bullish, bearish, or ranging)
- Major support and resistance levels
- Significant Order Blocks and Fair Value Gaps
- Key liquidity levels
- Dominant narrative (trend continuation or potential reversal)

**XAUUSD-Specific Considerations:**
- Gold tends to respect HTF levels more consistently than many forex pairs
- Round numbers ($1900, $1950, etc.) have enhanced significance on HTF
- Weekly and monthly opens often create significant levels
- Correlation with USD index provides additional context

**Decision Outputs:**
- Directional bias (bullish, bearish, or neutral)
- Key levels to monitor on lower timeframes
- Potential reversal zones
- No-trade zones where direction is unclear

### Step 2: Medium Timeframe (MTF) Analysis

The MTF helps identify specific trading opportunities within the HTF context.

**Key Elements to Identify:**
- Recent market structure shifts
- Valid Order Blocks aligned with HTF bias
- Fresh Fair Value Gaps
- Liquidity sweeps and inducement patterns
- Potential entry zones

**XAUUSD-Specific Considerations:**
- Gold often creates clearer Order Blocks on MTF due to its volatility
- Session transitions (Asian to London, London to NY) frequently create MTF opportunities
- Economic releases often create significant MTF structure shifts in XAUUSD

**Decision Outputs:**
- Specific POIs (Points of Interest) for potential entries
- Stop loss reference points
- Take profit targets based on HTF levels
- Trigger conditions for trade execution

### Step 3: Lower Timeframe (LTF) Analysis

The LTF provides precision for entry timing and stop placement.

**Key Elements to Identify:**
- Micro market structure
- Entry triggers (BOS, CHoCH, rejection candles)
- Stop loss refinement
- Early signs of reversal or continuation
- Liquidity engineering at key levels

**XAUUSD-Specific Considerations:**
- Gold's higher volatility creates more "noise" on LTF
- Requires slightly wider stop parameters than forex pairs
- Quick, sharp moves are common, especially during news events
- LTF signals against HTF bias are typically lower probability

**Decision Outputs:**
- Precise entry conditions
- Refined stop loss placement
- Initial take profit levels
- Trade management rules

### Step 4: Execution Timeframe (ETF) Analysis

The ETF is used for actual trade execution and initial management.

**Key Elements to Identify:**
- Exact entry candle patterns
- Stop loss placement behind relevant structure
- Early signs of trade validation or invalidation
- Initial momentum assessment

**XAUUSD-Specific Considerations:**
- Gold can move rapidly on ETF, requiring quick decision-making
- Price often "sweeps" beyond intended entry levels before reversing
- Limit orders often work better than market orders due to volatility
- Initial stops may need to be wider than final intended stop

**Decision Outputs:**
- Exact entry price and method (market or limit order)
- Precise stop loss placement
- Initial trade management rules
- Criteria for early exit if trade shows weakness

## Timeframe Alignment: The Key to High-Probability Trades

The alignment of signals across multiple timeframes significantly increases trade probability. Understanding the degrees of alignment helps prioritize trading opportunities.

### Perfect Alignment

Perfect alignment occurs when all timeframes show consistent signals and structure.

**Characteristics:**
- HTF shows clear directional bias
- MTF shows valid POI in direction of HTF bias
- LTF shows clear entry trigger at the MTF POI
- ETF confirms entry with strong candle pattern

**Trading Implications:**
- Highest probability setups
- Justifies larger position sizing
- Often leads to extended moves with minimal drawdown
- Allows for wider targets based on HTF levels

**XAUUSD Example:**
- HTF (4-hour) shows bullish market structure
- MTF (15-minute) shows valid bullish Order Block at key support
- LTF (5-minute) shows BOS and CHoCH at the Order Block
- ETF (1-minute) shows strong rejection candle with long lower wick

### Partial Alignment

Partial alignment occurs when most, but not all, timeframes show consistent signals.

**Characteristics:**
- HTF shows clear directional bias
- MTF shows valid POI in direction of HTF bias
- LTF or ETF shows conflicting or unclear signals
- Alternatively, MTF conflicts with HTF, but LTF/ETF align with one of them

**Trading Implications:**
- Moderate probability setups
- Justifies standard position sizing
- May experience more drawdown before moving to target
- Requires more active trade management

**XAUUSD Example:**
- HTF (4-hour) shows bullish market structure
- MTF (15-minute) shows valid bullish Order Block at key support
- LTF (5-minute) shows unclear structure or conflicting signals
- Decision: Wait for clearer LTF confirmation or take trade with reduced size

### Misalignment

Misalignment occurs when different timeframes show contradictory signals.

**Characteristics:**
- HTF shows one directional bias
- MTF shows opposite bias or unclear structure
- LTF and ETF may align with either HTF or MTF, creating confusion

**Trading Implications:**
- Low probability setups
- Best avoided by most traders
- If traded, requires very small position sizing
- Strict trade management with early exit criteria

**XAUUSD Example:**
- HTF (4-hour) shows bullish market structure
- MTF (15-minute) shows bearish Order Block and structure
- LTF (5-minute) shows mixed signals
- Decision: Avoid trading or wait for alignment to improve

## XAUUSD-Specific Multi-Timeframe Strategies

Gold markets have unique characteristics that create specific multi-timeframe opportunities.

### The London-New York Handoff Strategy

This strategy capitalizes on the transition between London and New York sessions, a period of high liquidity and potential direction changes in XAUUSD.

**Timeframe Setup:**
- HTF: 4-hour for overall bias
- MTF: 1-hour to identify session structure
- LTF: 15-minute for entry precision
- ETF: 5-minute for execution

**Process:**
1. Identify London session high and low (LH/LL)
2. Monitor price action during the session overlap (13:00-16:00 GMT)
3. Look for sweeps of LH/LL followed by reversal
4. Enter on LTF confirmation after the sweep
5. Target the opposite session extreme or next significant HTF level

**Key Success Factors:**
- Stronger when aligned with HTF bias
- More reliable when London session showed clear directional bias
- Enhanced probability when NY open creates a liquidity sweep
- Particularly effective on days with US economic releases

### The Asian Range Breakout Strategy

This strategy exploits the tendency of XAUUSD to consolidate during Asian hours before breaking out during London opening.

**Timeframe Setup:**
- HTF: 1-hour for overall bias
- MTF: 15-minute to identify Asian range
- LTF: 5-minute for breakout confirmation
- ETF: 1-minute for execution

**Process:**
1. Identify Asian session range (typically 00:00-08:00 GMT)
2. Mark range high and low as key levels
3. Determine which side aligns with HTF bias
4. Look for breakout during early London hours (08:00-10:00 GMT)
5. Enter on LTF confirmation after the breakout
6. Target measured move equal to range height

**Key Success Factors:**
- More reliable when Asian range is relatively tight
- Higher probability when breakout direction aligns with HTF bias
- Enhanced when London open volume is above average
- Particularly effective when Asian range coincides with significant HTF level

### The News Reaction Strategy

This strategy capitalizes on XAUUSD's sensitivity to economic releases, particularly those affecting gold or the US dollar.

**Timeframe Setup:**
- HTF: 4-hour or Daily for overall bias
- MTF: 1-hour to identify pre-news structure
- LTF: 15-minute for post-news reaction
- ETF: 5-minute for execution

**Process:**
1. Identify upcoming high-impact news event (FOMC, NFP, CPI, etc.)
2. Determine HTF bias before the news
3. Avoid trading immediately before the release
4. After initial volatility subsides (typically 15-30 minutes), look for:
   - False breakouts that reverse
   - Liquidity sweeps followed by strong reversal
   - Continuation moves that align with HTF bias
5. Enter on LTF confirmation of the post-news direction
6. Use wider stops due to increased volatility

**Key Success Factors:**
- More reliable when post-news direction aligns with HTF bias
- Higher probability when news creates liquidity sweeps before establishing direction
- Enhanced when multiple timeframes align quickly after news
- Particularly effective for FOMC announcements and major US economic data

## Common Multi-Timeframe Analysis Mistakes

Avoiding these common mistakes will improve your XAUUSD trading results:

### Mistake 1: Timeframe Inconsistency

**Problem:**
- Randomly switching between timeframes without a structured approach
- Cherry-picking timeframes that confirm bias while ignoring conflicting ones
- Using too many timeframes, creating analysis paralysis

**Solution:**
- Establish a consistent timeframe hierarchy for each trading style
- Always analyze in the same sequence (HTF → MTF → LTF → ETF)
- Acknowledge and account for conflicting signals between timeframes
- Limit analysis to 3-4 key timeframes to avoid confusion

### Mistake 2: Ignoring HTF Context

**Problem:**
- Focusing exclusively on lower timeframe setups
- Taking counter-trend trades without HTF justification
- Missing major support/resistance levels visible only on HTF

**Solution:**
- Always start analysis with HTF to establish context
- Give priority to trades aligned with HTF bias
- Require stronger confirmation for counter-trend trades
- Mark key HTF levels on all timeframes for reference

### Mistake 3: Forcing Trades in Unclear Conditions

**Problem:**
- Trading when timeframes show conflicting signals
- Entering based on a single timeframe's signal despite misalignment
- Overtrading during consolidation periods

**Solution:**
- Only take high-conviction trades with multi-timeframe alignment
- Accept that some days/periods won't offer clear setups
- Wait for alignment to improve before entering
- Reduce position size when alignment is imperfect

### Mistake 4: Improper Stop Placement Across Timeframes

**Problem:**
- Placing stops based solely on LTF structure
- Using arbitrary pip values rather than structural levels
- Ignoring HTF invalidation levels

**Solution:**
- Base initial stop placement on the timeframe used for entry decision
- Ensure stop is beyond relevant structure on both entry timeframe and MTF
- Consider volatility context from HTF when determining stop distance
- Use proper position sizing to accommodate wider stops when necessary

## The Multi-Timeframe Checklist for XAUUSD Trading

Use this checklist before every trade to ensure proper multi-timeframe analysis:

### Pre-Analysis Checklist
- [ ] Check economic calendar for upcoming gold-impacting events
- [ ] Identify current trading session (Asian, London, NY)
- [ ] Note current USD strength/weakness for context
- [ ] Be aware of recent volatility levels in XAUUSD

### HTF Analysis Checklist
- [ ] Identify current market structure (bullish, bearish, ranging)
- [ ] Mark major support/resistance levels
- [ ] Identify significant Order Blocks and Fair Value Gaps
- [ ] Determine overall directional bias

### MTF Analysis Checklist
- [ ] Confirm alignment with HTF or note discrepancies
- [ ] Identify recent market structure shifts
- [ ] Locate potential POIs for entry
- [ ] Determine potential stop loss and take profit levels

### LTF Analysis Checklist
- [ ] Look for entry triggers at MTF POIs
- [ ] Confirm micro market structure aligns with larger bias
- [ ] Identify precise stop loss placement
- [ ] Determine exact entry conditions

### Trade Execution Checklist
- [ ] Verify alignment across timeframes
- [ ] Ensure risk-reward meets minimum threshold (typically 1:2)
- [ ] Confirm position size is appropriate for setup quality
- [ ] Have clear trade management rules established

Mastering multi-timeframe analysis is essential for consistent success in XAUUSD trading. By following a structured approach, understanding timeframe relationships, and applying XAUUSD-specific strategies, you'll develop the ability to identify high-probability trading opportunities while avoiding common pitfalls. This systematic process forms the foundation for all trading decisions in the SMC and ICT methodology.
