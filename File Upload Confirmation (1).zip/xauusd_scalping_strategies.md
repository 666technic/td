# Top 10 XAUUSD Scalping Strategies Using SMC & ICT Principles

This section presents ten high-probability scalping strategies for XAUUSD based on Smart Money Concepts (SMC) and Inner Circle Trader (ICT) principles. Each strategy is designed for short-term trading with quick entries and exits, typically using 1-minute to 15-minute timeframes.

## Strategy 1: The Order Block Reversal Scalp

This strategy capitalizes on reactions at significant Order Blocks, particularly effective during high-liquidity sessions in XAUUSD.

### Market Context
- Works in both trending and ranging markets
- Most effective during London and NY sessions
- Particularly powerful at session transition periods
- Higher probability when aligned with HTF bias

### Core SMC/ICT Logic
The strategy exploits institutional order placement at key turning points. As price returns to these Order Blocks, the unfilled orders create a reaction that can be captured for quick profits. In XAUUSD, these reactions tend to be sharper and more reliable than in many forex pairs due to gold's higher volatility.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall bias and significant Order Blocks
- **MTF (15-minute)**: Confirm Order Block validity and potential reaction
- **LTF (5-minute)**: Fine-tune entry and identify precise stop placement
- **ETF (1-minute)**: Execute entry with precision timing

### Confirmation Stack
1. Valid Order Block with clear boundaries
2. RSI showing potential momentum shift at the Order Block
3. Rejection candle forming at the Order Block
4. Volume increase (if available) during rejection

### Step-by-Step Execution
1. Identify a significant Order Block on the 1-hour timeframe
2. Wait for price to return to the Order Block
3. Switch to 5-minute and 1-minute charts to monitor price reaction
4. Enter when a rejection candle forms with RSI momentum shift
5. Place stop loss beyond the Order Block (typically 10-15 pips in XAUUSD)
6. Target 1:2 risk-reward minimum (typically 20-30 pips)
7. Consider partial profit at 1:1 and move stop to breakeven

### Risk Management
- Maximum risk per trade: 1% of account
- Wider stops than forex pairs due to XAUUSD volatility
- Consider reducing position size during major news events
- Avoid trading during low-liquidity periods

## Strategy 2: The Fair Value Gap Fill Scalp

This strategy exploits the market's tendency to fill Fair Value Gaps (FVGs), which are particularly clear and frequent in XAUUSD.

### Market Context
- Works best in ranging or moderate trend conditions
- Most effective during Asian to London transition
- Higher probability when FVG is created by institutional activity
- Particularly effective after news-induced volatility subsides

### Core SMC/ICT Logic
Fair Value Gaps represent imbalances where price moved so quickly that no trading occurred in a specific range. These gaps act as magnets for price and often get filled in future price action. XAUUSD creates clear FVGs due to its volatility, providing excellent scalping opportunities.

### Timeframe Structure
- **HTF (15-minute)**: Identify significant FVGs
- **MTF (5-minute)**: Confirm FVG validity and monitor approach
- **LTF (1-minute)**: Fine-tune entry as price approaches the FVG
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Clear FVG with defined boundaries
2. Price approaching FVG with decreasing momentum
3. Small consolidation before FVG entry
4. Bollinger Band contraction indicating potential energy for the move

### Step-by-Step Execution
1. Identify a recent, unfilled FVG on the 15-minute chart
2. Wait for price to approach the edge of the FVG
3. Switch to 1-minute chart to monitor entry conditions
4. Enter when price begins to move into the FVG with momentum
5. Place stop loss beyond the recent swing point (typically 10-12 pips)
6. Target the complete fill of the FVG
7. Exit immediately if price shows strong rejection before filling the gap

### Risk Management
- Maximum risk per trade: 0.75% of account
- Use limit orders for precise entries
- Consider time-based exits if FVG doesn't fill within 30 minutes
- Avoid trading FVGs that conflict with major HTF structure

## Strategy 3: The Liquidity Sweep Reversal

This strategy capitalizes on institutional manipulation of retail stop orders, particularly effective at session highs/lows in XAUUSD.

### Market Context
- Works in both trending and ranging markets
- Most effective at London and NY session opens
- Higher probability at round numbers in XAUUSD
- Particularly powerful after consolidation periods

### Core SMC/ICT Logic
Institutions often push price beyond obvious support/resistance levels to trigger retail stop orders, creating liquidity for their own entries in the opposite direction. These liquidity sweeps are followed by reversals that can be captured for quick profits. XAUUSD exhibits particularly clear liquidity sweeps due to its popularity among retail traders.

### Timeframe Structure
- **HTF (1-hour)**: Identify key liquidity levels
- **MTF (15-minute)**: Monitor potential sweep development
- **LTF (5-minute)**: Confirm sweep and reversal pattern
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Price briefly pushing beyond a significant level (session high/low, round number)
2. Immediate rejection with a strong reversal candle
3. RSI or Stochastic divergence at the sweep point
4. Volume spike (if available) during the sweep and reversal

### Step-by-Step Execution
1. Identify potential liquidity levels (previous day high/low, session high/low)
2. Wait for price to briefly push beyond the level (typically 5-15 pips in XAUUSD)
3. Look for immediate rejection with a strong reversal candle
4. Enter on the close of the reversal candle or on a pullback to its 50% level
5. Place stop loss beyond the sweep extreme (typically 10-15 pips)
6. Target the origin of the sweep move or the next significant structure
7. Trail stops once price moves 1:1 risk-reward in your favor

### Risk Management
- Maximum risk per trade: 1% of account
- Reduce position size for sweeps at major technical levels
- Avoid chasing sweeps that don't immediately reverse
- Be cautious of false sweeps before major news events

## Strategy 4: The BOS Confirmation Scalp

This strategy exploits the continuation move following a confirmed Break of Structure (BOS) in XAUUSD.

### Market Context
- Works best in trending market conditions
- Most effective during high-volatility sessions
- Higher probability when aligned with HTF trend
- Particularly powerful after consolidation breakouts

### Core SMC/ICT Logic
When price breaks above a previous high (in an uptrend) or below a previous low (in a downtrend), it signals a potential continuation of the trend. This BOS is often followed by a small pullback before the trend resumes, creating an excellent entry opportunity. XAUUSD tends to produce cleaner BOS patterns than many forex pairs.

### Timeframe Structure
- **HTF (15-minute)**: Identify overall trend and significant structure
- **MTF (5-minute)**: Confirm BOS and monitor pullback
- **LTF (1-minute)**: Fine-tune entry during pullback
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Clear BOS on the 5-minute chart
2. Pullback to 38.2-61.8% of the BOS move
3. Bullish/bearish candle formation at the pullback level
4. Momentum indicator alignment (RSI or MACD) with the trend

### Step-by-Step Execution
1. Identify a clear BOS on the 5-minute chart
2. Wait for a pullback to the 38.2-61.8% Fibonacci retracement level
3. Look for a reversal candle at this pullback level
4. Enter on the close of the reversal candle
5. Place stop loss beyond the pullback swing (typically 8-12 pips in XAUUSD)
6. Target the previous extreme plus the height of the BOS move
7. Trail stops once price moves 1:1 risk-reward in your favor

### Risk Management
- Maximum risk per trade: 0.75% of account
- Avoid trading BOS against major HTF structure
- Be cautious of false breakouts, especially at round numbers
- Consider reducing position size during news events

## Strategy 5: The Session Open Drive

This strategy capitalizes on the directional moves that often occur during the first hour of major trading sessions, particularly London and New York opens in XAUUSD.

### Market Context
- Specifically designed for session opens
- Most effective at London and NY session opens
- Higher probability when Asian session was tight range
- Particularly powerful when aligned with HTF bias

### Core SMC/ICT Logic
The opening of major trading sessions often creates significant directional moves as institutional orders enter the market. These "opening drives" tend to be stronger in XAUUSD than many forex pairs due to gold's sensitivity to institutional participation. The strategy aims to capture the initial directional move of the session.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall bias
- **MTF (15-minute)**: Monitor session open development
- **LTF (5-minute)**: Confirm initial direction and entry
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Break of the first 15-minute candle high/low after session open
2. Volume increase (if available) in breakout direction
3. Momentum indicator alignment with breakout direction
4. Previous session bias alignment (if applicable)

### Step-by-Step Execution
1. Mark the high and low of the first 15-minute candle after session open
2. Wait for price to break above the high (for longs) or below the low (for shorts)
3. Enter on the breakout with a limit order 3-5 pips beyond the breakout level
4. Place stop loss at the opposite side of the first 15-minute candle
5. Target the next significant structure or a minimum 1:1.5 risk-reward
6. Consider closing before the first hour of the session ends if target not reached

### Risk Management
- Maximum risk per trade: 0.75% of account
- Wider stops than other strategies due to potential volatility
- Avoid trading session opens during major news events
- Consider reducing position size if the first candle is unusually large

## Strategy 6: The Breaker Block Retest

This strategy exploits the powerful continuation signal created when a former Order Block is broken and then retested as new support/resistance.

### Market Context
- Works best in trending market conditions
- Most effective during London and NY sessions
- Higher probability when aligned with HTF bias
- Particularly powerful after strong trend moves

### Core SMC/ICT Logic
When an Order Block is fully mitigated and then broken, it flips from support to resistance (or vice versa), becoming a "breaker block." These levels often provide strong support/resistance when retested, creating high-probability continuation opportunities. XAUUSD tends to respect breaker blocks more clearly than many forex pairs.

### Timeframe Structure
- **HTF (15-minute)**: Identify significant breaker blocks
- **MTF (5-minute)**: Confirm breaker block validity and monitor retest
- **LTF (1-minute)**: Fine-tune entry during retest
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Clear breaker block formation with defined boundaries
2. Price returning to test the breaker block from the opposite side
3. Rejection candle forming at the breaker block
4. Momentum indicator alignment with the overall trend

### Step-by-Step Execution
1. Identify a significant Order Block that has been broken
2. Wait for price to return to test this breaker block from the opposite side
3. Look for rejection at the breaker block level with a strong candle
4. Enter on the close of the rejection candle
5. Place stop loss beyond the breaker block (typically 8-12 pips in XAUUSD)
6. Target the next significant structure in the trend direction
7. Trail stops once price moves 1:1 risk-reward in your favor

### Risk Management
- Maximum risk per trade: 1% of account
- Reduce position size if breaker block is against HTF bias
- Avoid trading breaker blocks that have been tested multiple times
- Consider time-based exits if price consolidates at the breaker block

## Strategy 7: The Asian Range Breakout

This strategy capitalizes on the tendency of XAUUSD to consolidate during Asian hours before breaking out during London opening.

### Market Context
- Specifically designed for Asian to London transition
- Most effective when Asian session forms a tight range
- Higher probability when breakout direction aligns with HTF bias
- Particularly powerful when range coincides with significant level

### Core SMC/ICT Logic
The Asian session often creates a consolidation range in XAUUSD, building energy for a directional move during London hours. This range acts as an institutional preparation phase, with the subsequent breakout revealing the intended direction. The strategy aims to capture the initial breakout move.

### Timeframe Structure
- **HTF (1-hour)**: Identify overall bias
- **MTF (15-minute)**: Define Asian range boundaries
- **LTF (5-minute)**: Confirm breakout and entry
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Clear Asian range with defined high and low boundaries
2. Break of range high/low during early London hours
3. Strong momentum in breakout direction
4. Volume increase (if available) during breakout

### Step-by-Step Execution
1. Identify the high and low of the Asian session range (typically 00:00-08:00 GMT)
2. Wait for London session to begin (08:00 GMT)
3. Look for a decisive break of the Asian range high (for longs) or low (for shorts)
4. Enter on a pullback to the broken range boundary if it occurs
5. Alternatively, enter on the breakout candle close
6. Place stop loss inside the Asian range (typically 8-10 pips from entry)
7. Target a minimum of the range height projected from the breakout point

### Risk Management
- Maximum risk per trade: 0.75% of account
- Avoid trading breakouts against major HTF structure
- Be cautious of false breakouts, especially at round numbers
- Consider reducing position size if range is unusually tight

## Strategy 8: The Institutional Sweep Pattern

This strategy exploits the institutional pattern of sweeping liquidity before reversing to their intended direction, particularly common in XAUUSD.

### Market Context
- Works in both trending and ranging markets
- Most effective during high-liquidity sessions
- Higher probability at key technical levels
- Particularly powerful at round numbers in XAUUSD

### Core SMC/ICT Logic
Institutions often create a specific pattern: push price to sweep liquidity (triggering retail stops), create a Fair Value Gap during the reversal, and then continue in their intended direction. This pattern provides multiple confirmation elements and creates high-probability scalping opportunities in XAUUSD.

### Timeframe Structure
- **HTF (15-minute)**: Identify key liquidity levels
- **MTF (5-minute)**: Monitor sweep and reversal pattern
- **LTF (1-minute)**: Confirm pattern completion and entry
- **ETF (1-minute)**: Execute with precision timing

### Confirmation Stack
1. Liquidity sweep beyond a significant level
2. Strong reversal creating a Fair Value Gap
3. Consolidation after the reversal
4. Break in the reversal direction with momentum

### Step-by-Step Execution
1. Identify a liquidity sweep beyond a significant level
2. Look for a strong reversal creating a Fair Value Gap
3. Wait for a brief consolidation after the reversal
4. Enter when price breaks from the consolidation in the reversal direction
5. Place stop loss beyond the consolidation (typically 8-10 pips in XAUUSD)
6. Target the origin of the sweep move as minimum target
7. Consider extending target if momentum remains strong

### Risk Management
- Maximum risk per trade: 0.75% of account
- Avoid trading the pattern against major HTF structure
- Be cautious of multiple sweeps in choppy conditions
- Consider reducing position size during major news events

## Strategy 9: The Momentum Shift Scalp

Th
(Content truncated due to size limit. Use line ranges to read in chunks)