import React from 'react';
import Header from './Header'; // Changed from Navbar to Header
import Sidebar from './Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Header /> {/* Changed from Navbar to Header */}
      <div className="flex flex-1 pt-16"> {/* Adjust padding-top if Header height changes */}
        <Sidebar />
        <main className="flex-1 p-6 lg:p-8 overflow-y-auto page-transition">
          {children}
        </main>
      </div>
      {/* Footer can be added here if needed */}
    </div>
  );
};

export default Layout;
