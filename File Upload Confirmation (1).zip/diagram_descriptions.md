# Diagram Descriptions for XAUUSD Trading Guide

This document describes the diagrams needed to visually explain core SMC and ICT concepts in the XAUUSD trading guide.

## 1. Market Structure Diagram (BOS & CHoCH)

**Purpose:** To illustrate bullish and bearish market structure, Break of Structure (BOS), and Change of Character (CHoCH).

**Visual Elements:**
- **Bullish Structure:** Series of higher highs (HH) and higher lows (HL) represented by zigzag price action moving upwards.
  - Label HH and HL points.
  - Mark bullish BOS where price breaks above a previous HH.
  - Show a CHoCH where price breaks below the most recent HL, indicating a potential shift to bearish structure.
- **Bearish Structure:** Series of lower lows (LL) and lower highs (LH) represented by zigzag price action moving downwards.
  - Label LL and LH points.
  - Mark bearish BOS where price breaks below a previous LL.
  - Show a CHoCH where price breaks above the most recent LH, indicating a potential shift to bullish structure.

**Style:** Simple line drawing with clear labels and arrows indicating direction and breaks.

## 2. Liquidity Concepts Diagram (Sweeps & Inducement)

**Purpose:** To illustrate different types of liquidity and how they are targeted (swept) or used as inducement.

**Visual Elements:**
- **Equal Highs/Lows:** Show price forming two or more highs/lows at roughly the same level, marked with a horizontal line and labeled "Buy-side Liquidity" (above highs) or "Sell-side Liquidity" (below lows).
- **Liquidity Sweep:** Show price briefly moving beyond the liquidity level (e.g., above equal highs) and then reversing sharply. Mark the sweep area.
- **Inducement:** Show a minor pullback creating a small high/low before price continues to a more significant POI. Label the small high/low as "Inducement" and the subsequent move towards the POI.
- **Session Liquidity:** Show Asian, London, and NY session ranges, highlighting the highs and lows as potential liquidity targets.

**Style:** Simplified price action representation with clear labels, arrows showing sweeps, and shaded zones for sessions.

## 3. Point of Interest (POI) Diagrams (Order Block & FVG)

**Purpose:** To visually define Order Blocks (OB) and Fair Value Gaps (FVG).

**Visual Elements:**
- **Bullish Order Block:** Show the last down-close candle before a strong upward move. Highlight this candle and label it "Bullish OB". Show price returning to test this block later.
- **Bearish Order Block:** Show the last up-close candle before a strong downward move. Highlight this candle and label it "Bearish OB". Show price returning to test this block later.
- **Fair Value Gap (FVG):** Show a three-candle formation with a gap between the wick of the first candle and the wick of the third candle. Shade the gap area and label it "FVG". Show both bullish and bearish examples.

**Style:** Candlestick representations with highlighted areas, labels, and arrows showing price interaction.

## 4. Accumulation, Manipulation, Distribution (AMD) Cycle Diagram

**Purpose:** To illustrate the typical AMD cycle observed in markets.

**Visual Elements:**
- **Accumulation:** Show a period of price consolidation or ranging, labeled "Accumulation".
- **Manipulation:** Show price sweeping below the accumulation range low (or above the high), labeled "Manipulation (Sweep)".
- **Distribution:** Show price reversing strongly after the sweep and initiating a directional move away from the accumulation range, labeled "Distribution".

**Style:** Simplified price action representation showing the three distinct phases with clear labels and arrows indicating movement.

## 5. Strategy Implementation Flowchart (Example)

**Purpose:** To provide a visual decision-making guide for a specific strategy (e.g., Order Block Entry).

**Visual Elements:**
- Use standard flowchart shapes (rectangles for steps, diamonds for decisions).
- Start with "Identify HTF Bias".
- Decision: "Bullish or Bearish?"
- Steps: "Identify HTF OB", "Wait for Price Return to OB".
- Decision: "Rejection at OB on LTF?"
- Steps: "Enter Trade", "Set Stop Loss", "Set Targets".
- End with "Manage Trade".

**Style:** Clean flowchart layout with clear text and directional arrows.

## 6. Risk Management Visualization (Position Sizing)

**Purpose:** To visually explain the concept of fixed percentage risk position sizing.

**Visual Elements:**
- Show an account balance bar.
- Highlight a small percentage (e.g., 1%) labeled "Risk per Trade".
- Show a trade setup with entry, stop loss, and target.
- Illustrate how the stop loss distance determines the position size needed to keep the potential loss within the fixed percentage risk.
- Use simple formulas: Position Size = (Account Balance * Risk %) / (Stop Loss Distance * Pip Value).

**Style:** Infographic style with clear labels, simple graphics, and formulas.

These diagrams will be created using a consistent style and integrated into the relevant sections of the guide as outlined in the `visual_integration_plan.md`.
