import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'The Definitive SMC & ICT Guide for XAUUSD Trading',
  description: 'Comprehensive guide for mastering XAUUSD scalping and intraday trading using Smart Money Concepts and Inner Circle Trader principles',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
