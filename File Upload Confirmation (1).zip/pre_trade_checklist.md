# Pre-Trade Checklist for XAUUSD Trading

This comprehensive pre-trade checklist ensures that every trade you take aligns with SMC and ICT principles and has been thoroughly validated before execution. Following this structured approach will significantly improve your trading consistency and discipline.

## Market Context Analysis

Before considering any specific trade setup, assess the broader market context:

### 1. Global Market Assessment

**Economic Calendar Check:**
- [ ] Reviewed high-impact events for next 24 hours
- [ ] Noted specific times of gold-impacting releases
- [ ] Identified potential volatility periods
- [ ] Adjusted trading approach based on upcoming events

**Correlated Markets Check:**
- [ ] Assessed current USD Index (DXY) direction and structure
- [ ] Reviewed US Bond yields (particularly 10-year)
- [ ] Checked major equity indices for risk sentiment
- [ ] Noted any significant moves in related commodities (silver, oil)

**News and Sentiment Check:**
- [ ] Reviewed major financial headlines affecting gold
- [ ] Assessed current market risk sentiment (risk-on/risk-off)
- [ ] Noted any geopolitical developments impacting safe havens
- [ ] Checked for any central bank commentary on gold or inflation

### 2. XAUUSD Specific Assessment

**Session Analysis:**
- [ ] Identified current trading session (Asian, London, NY)
- [ ] Noted session transitions within next 4 hours
- [ ] Assessed typical XAUUSD behavior for current session
- [ ] Identified relevant ICT Killzone periods

**Volatility Assessment:**
- [ ] Checked current ATR relative to 20-day average
- [ ] Noted recent high/low volatility periods
- [ ] Adjusted position sizing based on current volatility
- [ ] Set appropriate stop distances for current conditions

**Key Levels Identification:**
- [ ] Marked major psychological levels ($1900, $1950, etc.)
- [ ] Identified daily/weekly/monthly opens
- [ ] Noted previous day high/low
- [ ] Marked significant HTF support/resistance levels

## Multi-Timeframe Structure Analysis

Analyze market structure across multiple timeframes to establish directional bias and identify key levels:

### 3. Higher Timeframe Analysis (4H/Daily)

**Market Structure:**
- [ ] Identified current HTF structure (bullish, bearish, ranging)
- [ ] Marked significant swing highs/lows
- [ ] Noted any recent BOS or CHoCH on HTF
- [ ] Determined overall directional bias

**Key SMC/ICT Elements:**
- [ ] Identified significant HTF Order Blocks
- [ ] Marked major Fair Value Gaps
- [ ] Noted important liquidity levels
- [ ] Identified any PD arrays or OTE zones

**Trend Assessment:**
- [ ] Determined trend direction using price action
- [ ] Confirmed with moving averages (50/200)
- [ ] Assessed trend strength and maturity
- [ ] Noted any divergence on HTF momentum indicators

### 4. Medium Timeframe Analysis (1H/15M)

**Market Structure:**
- [ ] Identified current MTF structure relative to HTF
- [ ] Marked recent swing highs/lows
- [ ] Noted any recent BOS or CHoCH on MTF
- [ ] Determined if MTF aligns with HTF bias

**Key SMC/ICT Elements:**
- [ ] Identified fresh MTF Order Blocks
- [ ] Marked recent Fair Value Gaps
- [ ] Noted intraday liquidity levels
- [ ] Identified potential Breaker Blocks

**Potential Entry Zones:**
- [ ] Marked high-probability POIs aligned with HTF
- [ ] Identified optimal entry timeframes
- [ ] Noted key invalidation levels
- [ ] Ranked POIs by probability and quality

### 5. Lower Timeframe Analysis (5M/1M)

**Market Structure:**
- [ ] Identified current LTF structure relative to MTF
- [ ] Marked micro swing highs/lows
- [ ] Noted any recent BOS or CHoCH on LTF
- [ ] Determined if LTF aligns with higher timeframes

**Entry Precision:**
- [ ] Identified specific entry triggers at POIs
- [ ] Marked precise stop loss levels
- [ ] Determined optimal entry candle patterns
- [ ] Noted momentum conditions for entry

## Trade Setup Validation

Once a potential trade is identified, validate it against strict criteria:

### 6. Setup Quality Assessment

**SMC/ICT Concept Validation:**
- [ ] Confirmed setup is based on valid SMC/ICT concept
- [ ] Verified concept application is correct
- [ ] Ensured setup is not forced or ambiguous
- [ ] Confirmed setup has historical reliability

**Multi-Timeframe Alignment:**
- [ ] Verified alignment between HTF, MTF, and LTF
- [ ] Noted degree of alignment (perfect, partial, conflicting)
- [ ] Ensured entry direction matches HTF bias
- [ ] Adjusted position size based on alignment quality

**Confluence Factors:**
- [ ] Identified multiple confluence factors supporting setup
- [ ] Noted alignment with key psychological levels
- [ ] Checked indicator confirmation (if applicable)
- [ ] Verified structural confluence (multiple concepts overlapping)

### 7. Risk-Reward Assessment

**Stop Loss Validation:**
- [ ] Placed stop beyond relevant structure
- [ ] Verified stop distance is appropriate for volatility
- [ ] Ensured stop is not at obvious liquidity level
- [ ] Confirmed stop placement follows SMC/ICT principles

**Target Identification:**
- [ ] Set targets based on significant structure
- [ ] Verified minimum risk-reward ratio (typically 1:2+)
- [ ] Identified multiple targets for scaling out
- [ ] Noted potential obstacles between entry and targets

**Position Sizing Calculation:**
- [ ] Calculated position size based on account risk parameters
- [ ] Adjusted size based on setup quality
- [ ] Verified risk percentage is appropriate (typically 0.5-2%)
- [ ] Ensured position size is comfortable psychologically

### 8. Execution Planning

**Entry Method:**
- [ ] Determined specific entry method (market, limit, stop)
- [ ] Identified exact entry price or trigger
- [ ] Planned for alternative scenarios
- [ ] Prepared for potential slippage

**Trade Management Rules:**
- [ ] Established clear stop adjustment rules
- [ ] Determined scale-out levels and percentages
- [ ] Set trailing stop parameters
- [ ] Identified specific exit criteria

**Psychological Readiness:**
- [ ] Assessed current mental state for trading
- [ ] Verified emotional neutrality toward the setup
- [ ] Confirmed trading for the right reasons
- [ ] Prepared for all possible outcomes

## Final Pre-Execution Checklist

Complete this final checklist immediately before placing any order:

### 9. Last-Minute Verification

**Market Conditions Check:**
- [ ] Verified no breaking news affecting gold
- [ ] Confirmed market is not in pre-news consolidation
- [ ] Checked for unusual volatility or liquidity conditions
- [ ] Ensured setup is still valid

**Technical Validation:**
- [ ] Confirmed price is at or approaching entry zone
- [ ] Verified all entry conditions are still present
- [ ] Checked for any new conflicting signals
- [ ] Ensured setup hasn't degraded in quality

**Order Details Verification:**
- [ ] Double-checked all order parameters
- [ ] Verified correct position size
- [ ] Confirmed stop loss and take profit levels
- [ ] Ensured order type is appropriate

### 10. Post-Entry Plan

**Immediate Actions:**
- [ ] Planned first adjustment to stop loss
- [ ] Determined criteria for early exit if needed
- [ ] Established rules for adding to position (if applicable)
- [ ] Set alerts for key price levels

**Contingency Planning:**
- [ ] Prepared for adverse scenario
- [ ] Established maximum drawdown tolerance
- [ ] Determined criteria for emergency exit
- [ ] Planned response to unexpected news events

**Documentation Setup:**
- [ ] Prepared trade journal entry
- [ ] Set up screenshot documentation
- [ ] Noted key observations about setup
- [ ] Prepared to record trade management decisions

## XAUUSD-Specific Considerations

Add these gold-specific checks to your pre-trade process:

### 11. Gold Market Nuances

**Volatility Adjustments:**
- [ ] Widened stops appropriately for XAUUSD's higher volatility
- [ ] Adjusted targets to account for gold's movement characteristics
- [ ] Considered volatility-based position sizing
- [ ] Prepared for potential price spikes at key levels

**Round Number Psychology:**
- [ ] Noted proximity to major psychological levels
- [ ] Adjusted stops to avoid round number liquidity sweeps
- [ ] Considered round numbers as potential targets
- [ ] Assessed historical reaction at nearby round numbers

**Session-Specific Behavior:**
- [ ] Considered XAUUSD's typical behavior in current session
- [ ] Adjusted expectations based on time of day
- [ ] Noted potential session transition effects
- [ ] Considered typical gold liquidity for current time

**Correlation Alignment:**
- [ ] Verified DXY movement supports trade direction
- [ ] Checked if bond yields movement aligns with setup
- [ ] Noted any divergence from typical correlations
- [ ] Considered impact of current risk sentiment on gold

## Implementation Guidelines

To effectively use this checklist in your trading:

### Daily Preparation

1. Complete the Market Context Analysis at the beginning of your trading session
2. Perform the Multi-Timeframe Structure Analysis as part of your regular market scanning
3. Keep the checklist accessible in printed or digital form
4. Develop the habit of systematically working through each section

### For Each Trade

1. Complete the Trade Setup Validation for every potential trade
2. Use the Final Pre-Execution Checklist immediately before placing orders
3. Document which checklist items influenced your decision
4. Note any checklist items that were skipped or compromised

### Continuous Improvement

1. Review completed checklists after trade completion
2. Identify which checklist items were most predictive of success
3. Refine and personalize the checklist based on your results
4. Add specific items based on your trading style and preferences

By consistently using this comprehensive pre-trade checklist, you'll develop a structured approach to XAUUSD trading that minimizes impulsive decisions and ensures alignment with SMC and ICT principles. This systematic process is a cornerstone of professional trading discipline.
