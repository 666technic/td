# SMC & ICT Trading Concepts Research Notes

## Smart Money Concepts (SMC)

Smart Money Concepts (SMC) is a strategic trading approach that focuses on understanding the actions and motives of market makers, including institutions like banks and hedge funds. The core concept involves replicating the trading behavior of these influential entities, with a specific focus on variables such as supply, demand dynamics, and the structural aspects of the market.

### Key SMC Concepts:

#### Order Blocks (OBs)
- Concentrated areas of limit orders awaiting execution
- Identified on charts by analyzing past price movements for significant shifts
- Serve as pivotal points in price action trading, influencing market's future direction
- When buy or sell orders cluster at a specific price level, it establishes robust support or resistance
- Can absorb pressure and trigger price reversals or consolidation
- Types: Decisional vs. Extreme OBs, Mitigation vs. Breaker Blocks

#### Fair Value Gap (FVG)
- Represents an imbalance in the market
- Occurs when price departs from a specific level with limited trading activity
- Results in one-directional price movement
- In a bearish trend: price range between the low of the previous candle and high of the following candle
- In a bullish trend: opposite conditions apply
- Can become magnets for price in future price action

#### Liquidity
- Price levels where orders accumulate, rendering an asset class "liquid"
- Price points with available orders ready for transactions
- Types: Buy-side (where short sellers place stops) and Sell-side (where long-biased traders place stops)
- Often found at or near extremes (tops and bottoms of ranges)
- "Smart money" players accumulate or distribute positions near these levels
- After stops are triggered, price often reverses and seeks liquidity at the opposite extreme

#### Break of Structure (BOS)
- Fundamental element of SMC market analysis
- Occurs when price surpasses previous high (in uptrend) or drops below established lows (in downtrend)
- Signals potential trend change
- Used as a level to trade off of once price has traded through it

#### Change of Character (ChoCH)
- Signals when price drops below previously established lows (in uptrend) or surpasses previous high (in downtrend)
- SMC traders leverage understanding of these patterns to make informed decisions
- Often used together with BOS to confirm trend changes

## Inner Circle Trader (ICT) Concepts

The Inner Circle Trader (ICT) methodology was developed by a trader known as the Inner Circle Trader and is considered an evolved version of SMC. It's a price action-based trading approach that uses little to no trend following or momentum indicators.

### Key ICT Concepts:

#### Displacement
- Very powerful move in price action resulting in strong selling or buying pressure
- Appears as single or group of candles positioned in same direction
- Candles typically have large real bodies and short wicks (little disagreement between buyers/sellers)
- Often occurs after liquidity level breach
- Can result in creation of Fair Value Gap and Market Structure Shift

#### Market Structure Shift
- In uptrend: price makes higher highs and higher lows
- In downtrend: price makes lower highs and lower lows
- Market structure shift occurs when previous trend is broken
- In uptrend: shift happens when lower low is made
- In downtrend: shift happens when higher high is made
- Tends to occur after displacement
- Traders use this level to look for further signs of trend change

#### Inducement
- Counter-trend moves resulting from lower timeframe liquidity hunting
- Price bounces or gets rejected, then targets previous short-term high/low before continuing in longer-term trend direction
- Specifically targets short-term highs/lows as areas where stops might be placed
- Can be seen in formation of bull and bear flags
- After liquidity is taken out, price can continue in previous direction

#### Optimal Trade Entry (OTE)
- Represents best places to enter a trade
- Identified using Fibonacci drawing tool
- Usually lies between 61.8% and 78.6% retracement of an expansion range
- After Market Structure Shift and new leg formation, the bounce that follows offers opportunity to take position in direction of new leg
- Fibonacci retracement levels help identify optimal entry points

#### Balanced Price Range
- Result of aggressive move up immediately followed by aggressive move down (or vice versa)
- Creates essentially a double Fair Value Gap
- Acts as a magnet to price before continuation move higher or lower
- Can signal beginning of Market Structure Shift
- Price often retests and rejects from these areas

## Relationship with Wyckoff Theory

The term "Smart Money" was first introduced by Richard D. Wyckoff, who developed the Wyckoff Method to reveal intentions of "smart money" in the market. Both SMC and Wyckoff Method provide insights into market dynamics by analyzing actions of well-informed investors and institutions.

### Wyckoff Price Cycle (similar to SMC concepts):
1. **Accumulation**: Smart money quietly accumulates positions while public is bearish
2. **Markup**: Smart money pushes prices higher, public begins to notice and enter
3. **Distribution**: Smart money sells accumulated positions to less-informed public
4. **Markdown**: Prices decline, market enters downtrend, public sentiment turns bearish

## Application to XAUUSD Trading

SMC and ICT concepts are particularly applicable to XAUUSD (Gold) trading due to the instrument's liquidity and volatility characteristics. Gold is traded by both retail and institutional players, making it an ideal market for identifying smart money movements.

Key considerations for applying these concepts to XAUUSD:
- Gold can be more volatile than forex pairs, requiring careful stop placement
- Institutional interest in gold creates clear liquidity zones and order blocks
- Fair Value Gaps tend to be more pronounced in gold due to its 24-hour trading nature and session transitions
- Market Structure Shifts can be more dramatic in gold during high-impact economic events
- Multiple timeframe analysis is crucial for gold trading using SMC/ICT concepts

Resources for XAUUSD-specific SMC/ICT applications include numerous YouTube tutorials, TradingView charts, and specialized trading courses focused on gold trading using these methodologies.
