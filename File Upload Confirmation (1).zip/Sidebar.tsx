"use client";

import React, { useState } from 'react';
import Link from 'next/link';

interface SidebarProps {}

const Sidebar: React.FC<SidebarProps> = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      {/* Mobile sidebar toggle button */}
      <button 
        className="fixed bottom-4 right-4 z-50 md:hidden bg-yellow-600 text-white p-3 rounded-full shadow-lg"
        onClick={toggleSidebar}
      >
        {isOpen ? 'X' : '≡'}
      </button>

      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full bg-white shadow-lg transition-all duration-300 ease-in-out z-40 pt-16 
        ${isOpen ? 'w-64 translate-x-0' : 'w-64 -translate-x-full md:translate-x-0'}`}
      >
        <div className="p-4">
          <h3 className="text-lg font-bold text-yellow-600 mb-4">Guide Contents</h3>
          
          <div className="space-y-6">
            {/* Part 1 */}
            <div>
              <h4 className="font-semibold text-gray-700 mb-2">Part 1: SMC & ICT Encyclopedia</h4>
              <ul className="space-y-2 pl-2">
                <li>
                  <Link href="/" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Introduction
                  </Link>
                </li>
                <li>
                  <Link href="/terminology" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Core Terminology
                  </Link>
                </li>
                <li>
                  <Link href="/market-structure" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Market Structure
                  </Link>
                </li>
                <li>
                  <Link href="/liquidity-concepts" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Liquidity Concepts
                  </Link>
                </li>
                <li>
                  <Link href="/poi-identification" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    POI Identification
                  </Link>
                </li>
                <li>
                  <Link href="/advanced-ict" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Advanced ICT Concepts
                  </Link>
                </li>
                <li>
                  <Link href="/multi-timeframe" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Multi-Timeframe Analysis
                  </Link>
                </li>
              </ul>
            </div>
            
            {/* Part 2 */}
            <div>
              <h4 className="font-semibold text-gray-700 mb-2">Part 2: Indicator Synergy</h4>
              <ul className="space-y-2 pl-2">
                <li>
                  <Link href="/indicators-role" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Role of Indicators
                  </Link>
                </li>
                <li>
                  <Link href="/standard-indicators" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Standard Indicators
                  </Link>
                </li>
                <li>
                  <Link href="/lux-algo" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Lux Algo Suite
                  </Link>
                </li>
                <li>
                  <Link href="/other-tools" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Other Tools
                  </Link>
                </li>
              </ul>
            </div>
            
            {/* Part 3 */}
            <div>
              <h4 className="font-semibold text-gray-700 mb-2">Part 3: Strategy Playbook</h4>
              <ul className="space-y-2 pl-2">
                <li>
                  <Link href="/scalping-strategies" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Scalping Strategies
                  </Link>
                </li>
                <li>
                  <Link href="/intraday-strategies" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Intraday Strategies
                  </Link>
                </li>
              </ul>
            </div>
            
            {/* Part 4 */}
            <div>
              <h4 className="font-semibold text-gray-700 mb-2">Part 4: Execution & Risk</h4>
              <ul className="space-y-2 pl-2">
                <li>
                  <Link href="/pre-trade-checklist" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Pre-Trade Checklist
                  </Link>
                </li>
                <li>
                  <Link href="/risk-management" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Risk Management
                  </Link>
                </li>
                <li>
                  <Link href="/psychological-edge" className="text-gray-600 hover:text-yellow-600 transition-colors">
                    Psychological Edge
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
