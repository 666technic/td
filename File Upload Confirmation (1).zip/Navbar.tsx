import React from 'react';
import Link from 'next/link';

const Navbar: React.FC = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-10 bg-white shadow-md h-16 flex items-center px-6">
      <Link href="/" className="text-xl font-bold text-gray-800 hover:text-yellow-600 transition-colors">
        XAUUSD SMC & ICT Guide
      </Link>
      {/* Add other navbar items if needed */}
    </nav>
  );
};

export default Navbar;
